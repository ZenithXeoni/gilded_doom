
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.entity.Entity;

import net.mcreator.gildeddoom.procedures.BookofGildedBanishmentItemInInventoryTickProcedure;

public class BookOfGildedBanishmentItem extends PickaxeItem {
    public BookOfGildedBanishmentItem() {
        super(new Tier() {
            public int getUses() {
                return 250;
            }

            public float getSpeed() {
                return 4f;
            }

            public float getAttackDamageBonus() {
                return 2f;
            }

            public int getLevel() {
                return 1;
            }

            public int getEnchantmentValue() {
                return 25;
            }

            public Ingredient getRepairIngredient() {
                return Ingredient.of(new ItemStack(Blocks.GILDED_BLACKSTONE));
            }
        }, 1, -2f, new Item.Properties().tab(CreativeModeTab.TAB_TOOLS).fireResistant());
    }

    @Override
    public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(itemstack, world, entity, slot, selected);
        BookofGildedBanishmentItemInInventoryTickProcedure
                .execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("x", entity.getX()).put("y", entity.getY()).put("z", entity.getZ()).put("world", world).put("entity", entity).build());
    }

    @Override
    public boolean hurtEnemy(ItemStack itemstack, LivingEntity target, LivingEntity attacker) {
        Level world = attacker.level;
        if (attacker instanceof Player player) {
            // Check for Critical Hit
            if (player.fallDistance > 0.0F && !player.isOnGround() && !player.onClimbable() && !player.isInWater() && !player.hasEffect(MobEffects.BLINDNESS) && !player.isPassenger()) {

                // 1. Apply Gilded Stasis
                target.addEffect(new MobEffectInstance(GildedDoomModMobEffects.GILDED_STASIS, 60, 0));

                // 2. Play Door Breaking Sound
                world.playSound(null, target.getX(), target.getY(), target.getZ(),
                        SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.PLAYERS, 1.0F, 0.5F);
                world.playSound(null, target.getX(), target.getY(), target.getZ(),
                        SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0F, 0.5F);

                // 3. Blackstone Particle Effects
                if (!world.isClientSide() && world instanceof ServerLevel serverWorld) {
                    // This creates a burst of particles based on the Gilded Blackstone block
                    serverWorld.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.GILDED_BLACKSTONE.defaultBlockState()),
                            target.getX(), target.getY() + 1, target.getZ(), 20, 0.3, 0.3, 0.3, 0.15);
                }
            }
        }
        return super.hurtEnemy(itemstack, target, attacker);
    }
}