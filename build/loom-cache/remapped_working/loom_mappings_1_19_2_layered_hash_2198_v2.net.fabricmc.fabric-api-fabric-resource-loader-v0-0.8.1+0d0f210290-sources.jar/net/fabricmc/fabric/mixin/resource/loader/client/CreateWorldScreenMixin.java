/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.loader.client;

import java.io.File;
import java.util.concurrent.CompletableFuture;

import com.google.gson.JsonElement;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.resource.loader.ModResourcePackCreator;
import net.fabricmc.fabric.impl.resource.loader.ModResourcePackUtil;
import net.fabricmc.fabric.mixin.resource.loader.ResourcePackManagerAccessor;
import net.minecraft.Util;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.gui.screens.worldselection.WorldCreationContext;
import net.minecraft.client.gui.screens.worldselection.WorldGenSettingsComponent;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.WorldLoader;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.level.DataPackConfig;
import net.minecraft.world.level.levelgen.WorldGenSettings;

@Mixin(CreateWorldScreen.class)
public abstract class CreateWorldScreenMixin extends Screen {
	@Unique
	private static DataPackConfig defaultDataPackSettings;

	@Shadow
	private PackRepository packManager;

	@Shadow
	@Final
	private static Logger LOGGER;

	@Shadow
	@Final
	public WorldGenSettingsComponent moreOptionsDialog;

	@Shadow
	protected DataPackConfig dataPackSettings;

	@Shadow
	private static WorldLoader.InitConfig createServerConfig(PackRepository resourcePackManager, DataPackConfig dataPackSettings) {
		return null;
	}

	@Shadow
	@Nullable
	protected abstract Pair<File, PackRepository> getScannedPack();

	private CreateWorldScreenMixin() {
		super(null);
	}

	@ModifyVariable(method = "create(Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/gui/screen/Screen;)V",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/world/CreateWorldScreen;createServerConfig(Lnet/minecraft/resource/ResourcePackManager;Lnet/minecraft/resource/DataPackSettings;)Lnet/minecraft/server/SaveLoading$ServerConfig;"))
	private static PackRepository onCreateResManagerInit(PackRepository manager) {
		// Add mod data packs to the initial res pack manager so they are active even if the user doesn't use custom data packs
		((ResourcePackManagerAccessor) manager).getProviders().add(new ModResourcePackCreator(PackType.SERVER_DATA));
		return manager;
	}

	@Redirect(method = "create(Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/gui/screen/Screen;)V", at = @At(value = "FIELD", target = "Lnet/minecraft/resource/DataPackSettings;SAFE_MODE:Lnet/minecraft/resource/DataPackSettings;", ordinal = 0))
	private static DataPackConfig replaceDefaultSettings() {
		return (defaultDataPackSettings = ModResourcePackUtil.createDefaultDataPackSettings());
	}

	@ModifyArg(method = "create(Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/gui/screen/Screen;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/world/CreateWorldScreen;<init>(Lnet/minecraft/client/gui/screen/Screen;Lnet/minecraft/resource/DataPackSettings;Lnet/minecraft/client/gui/screen/world/MoreOptionsDialog;)V"), index = 1)
	private static DataPackConfig useReplacedDefaultSettings(DataPackConfig dataPackSettings) {
		return defaultDataPackSettings;
	}

	@Redirect(method = "method_41854", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/registry/DynamicRegistryManager$Mutable;toImmutable()Lnet/minecraft/util/registry/DynamicRegistryManager$Immutable;"))
	private static RegistryAccess.Frozen loadDynamicRegistry(RegistryAccess.Writable mutableRegistryManager, ResourceManager dataPackManager) {
		// This loads the dynamic registry from the data pack
		RegistryOps.createAndLoad(JsonOps.INSTANCE, mutableRegistryManager, dataPackManager);
		return mutableRegistryManager.freeze();
	}

	/**
	 * Load the DynamicRegistryManager again to fix GeneratorOptions not having custom dimensions.
	 * Taken from {@link CreateWorldScreen#tryApplyNewDataPacks(PackRepository)}.
	 */
	@SuppressWarnings("JavadocReference")
	@Inject(method = "startServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/world/CreateWorldScreen;clearDataPackTempDir()V"))
	private void loadDatapackDimensions(CallbackInfo ci) {
		CompletableFuture<Void> future = WorldLoader.load(createServerConfig(getScannedPack().getSecond(), dataPackSettings), (resourceManager, dataPackSettings1) -> {
			WorldCreationContext holder = moreOptionsDialog.settings();
			RegistryAccess.Writable newDrm = RegistryAccess.builtinCopy();
			DynamicOps<JsonElement> heldOps = RegistryOps.create(JsonOps.INSTANCE, holder.registryAccess());
			DynamicOps<JsonElement> newOps = RegistryOps.createAndLoad(JsonOps.INSTANCE, newDrm, resourceManager);
			DataResult<WorldGenSettings> result = WorldGenSettings.CODEC.encodeStart(heldOps, holder.worldGenSettings())
					.flatMap(json -> WorldGenSettings.CODEC.parse(newOps, json));
			return Pair.of(result, newDrm.freeze());
		}, (resourceManager, dataPackContents, drm, result) -> {
			resourceManager.close();
			WorldGenSettings options = result.getOrThrow(false, Util.prefix("Error parsing worldgen settings after loading data packs: ", LOGGER::error));
			WorldCreationContext holder = new WorldCreationContext(options, result.lifecycle().add(drm.allElementsLifecycle()), drm, dataPackContents);
			((MoreOptionsDialogAccessor) moreOptionsDialog).callSetGeneratorOptionsHolder(holder);
			return null;
		}, Util.backgroundExecutor(), minecraft);

		minecraft.managedBlock(future::isDone);
	}

	@Inject(method = "getScannedPack",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/resource/ResourcePackManager;scanPacks()V", shift = At.Shift.BEFORE))
	private void onScanPacks(CallbackInfoReturnable<Pair<File, PackRepository>> cir) {
		// Allow to display built-in data packs in the data pack selection screen at world creation.
		((ResourcePackManagerAccessor) this.packManager).getProviders().add(new ModResourcePackCreator(PackType.SERVER_DATA));
	}
}
