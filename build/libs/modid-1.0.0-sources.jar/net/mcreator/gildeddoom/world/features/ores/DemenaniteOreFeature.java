
package net.mcreator.gildeddoom.world.features.ores;

import net.mcreator.gildeddoom.init.GildedDoomModBlocks;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3122;
import net.minecraft.class_3124;
import net.minecraft.class_3825;
import net.minecraft.class_3827;
import net.minecraft.class_5281;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6803;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;

import java.util.function.Predicate;
import java.util.List;

public class DemenaniteOreFeature extends class_3122 {
	public static DemenaniteOreFeature FEATURE = null;
	public static class_6880<class_2975<class_3124, ?>> CONFIGURED_FEATURE = null;
	public static class_6880<class_6796> PLACED_FEATURE = null;

	public static class_3031<?> feature() {
		FEATURE = new DemenaniteOreFeature();
		CONFIGURED_FEATURE = class_6803.method_39708("gilded_doom:demenanite_ore", FEATURE, new class_3124(DemenaniteOreFeatureRuleTest.INSTANCE, GildedDoomModBlocks.DEMENANITE_ORE.method_9564(), 5));
		PLACED_FEATURE = class_6817.method_39737("gilded_doom:demenanite_ore", CONFIGURED_FEATURE,
				List.of(class_6793.method_39623(10), class_5450.method_39639(), class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(64)), class_6792.method_39614()));
		return FEATURE;
	}

	public static final Predicate<BiomeSelectionContext> GENERATE_BIOMES = BiomeSelectors.all();

	public DemenaniteOreFeature() {
		super(class_3124.field_24896);
	}

	public boolean method_13151(class_5821<class_3124> context) {
		class_5281 world = context.method_33652();
		class_5321<class_1937> dimensionType = world.method_8410().method_27983();
		boolean dimensionCriteria = false;
		if (dimensionType == class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))
			dimensionCriteria = true;
		if (!dimensionCriteria)
			return false;
		return super.method_13151(context);
	}

	private static class DemenaniteOreFeatureRuleTest extends class_3825 {
		static final DemenaniteOreFeatureRuleTest INSTANCE = new DemenaniteOreFeatureRuleTest();
		static final com.mojang.serialization.Codec<DemenaniteOreFeatureRuleTest> codec = com.mojang.serialization.Codec.unit(() -> INSTANCE);
		static final class_3827<DemenaniteOreFeatureRuleTest> CUSTOM_MATCH = class_2378.method_10230(class_2378.field_16792, new class_2960("gilded_doom:demenanite_ore_match"), () -> codec);

		public boolean method_16768(class_2680 blockAt, class_5819 random) {
			boolean blockCriteria = false;
			if (blockAt.method_26204() == GildedDoomModBlocks.PURGATORY_STONE)
				blockCriteria = true;
			return blockCriteria;
		}

		protected class_3827<?> method_16766() {
			return CUSTOM_MATCH;
		}
	}
}
