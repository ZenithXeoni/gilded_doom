
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.mcreator.gildeddoom.world.features.ores.IronInfusedPurgatoryStoneFeature;
import net.minecraft.class_2378;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_5321;
import net.mcreator.gildeddoom.world.features.ores.GildedPurgatoryStoneFeature;
import net.mcreator.gildeddoom.world.features.ores.DemenaniteOreFeature;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;

import java.util.function.Predicate;

public class GildedDoomModFeatures {
	public static void load() {
		register("gilded_purgatory_stone", GildedPurgatoryStoneFeature.feature(), GildedPurgatoryStoneFeature.GENERATE_BIOMES, class_2893.class_2895.field_13176);
		register("iron_infused_purgatory_stone", IronInfusedPurgatoryStoneFeature.feature(), IronInfusedPurgatoryStoneFeature.GENERATE_BIOMES, class_2893.class_2895.field_13176);
		register("demenanite_ore", DemenaniteOreFeature.feature(), DemenaniteOreFeature.GENERATE_BIOMES, class_2893.class_2895.field_13176);
	}

	private static void register(String registryName, class_3031 feature, Predicate<BiomeSelectionContext> biomes, class_2893.class_2895 genStep) {
		class_2378.method_10230(class_2378.field_11138, new class_2960(GildedDoomMod.MODID, registryName), feature);
		BiomeModifications.addFeature(biomes, genStep, class_5321.method_29179(class_2378.field_35758, new class_2960(GildedDoomMod.MODID, registryName)));
	}
}
