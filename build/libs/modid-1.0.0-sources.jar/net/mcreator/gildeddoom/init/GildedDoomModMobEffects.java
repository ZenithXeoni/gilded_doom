
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.mcreator.gildeddoom.potion.UltimatePowerMobEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.mcreator.gildeddoom.potion.TheEchoFallExpirenceMobEffect;
import net.mcreator.gildeddoom.potion.PendingDeathMobEffect;
import net.mcreator.gildeddoom.potion.GildedStasisMobEffect;
import net.mcreator.gildeddoom.potion.GildedImmunityMobEffect;
import net.mcreator.gildeddoom.potion.GildedEmpowermentMobEffect;
import net.mcreator.gildeddoom.potion.DeathsMarkMobEffect;
import net.mcreator.gildeddoom.GildedDoomMod;

public class GildedDoomModMobEffects {
	public static class_1291 THE_ECHO_FALL_EXPERIENCE;
	public static class_1291 DEATHS_MARK;
	public static class_1291 PENDING_DEATH;
	public static class_1291 ULTIMATE_POWER;
	public static class_1291 GILDED_STASIS;
	public static class_1291 GILDED_IMMUNITY;
	public static class_1291 GILDED_EMPOWERMENT;

	public static void load() {
		THE_ECHO_FALL_EXPERIENCE = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "the_echo_fall_experience"), new TheEchoFallExpirenceMobEffect());
		DEATHS_MARK = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "deaths_mark"), new DeathsMarkMobEffect());
		PENDING_DEATH = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "pending_death"), new PendingDeathMobEffect());
		ULTIMATE_POWER = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "ultimate_power"), new UltimatePowerMobEffect());
		GILDED_STASIS = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "gilded_stasis"), new GildedStasisMobEffect());
		GILDED_IMMUNITY = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "gilded_immunity"), new GildedImmunityMobEffect());
		GILDED_EMPOWERMENT = class_2378.method_10230(class_2378.field_11159, new class_2960(GildedDoomMod.MODID, "gilded_empowerment"), new GildedEmpowermentMobEffect());
	}
}
