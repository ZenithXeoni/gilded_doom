
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;

public class GildedDoomModSounds {
	public static class_3414 GOT_ANY_GRAPES = new class_3414(new class_2960("gilded_doom", "got_any_grapes"));
	public static class_3414 GOT_ANY_GLUE = new class_3414(new class_2960("gilded_doom", "got_any_glue"));
	public static class_3414 ULTIMATE_POWER_CHARGE_UP = new class_3414(new class_2960("gilded_doom", "ultimate_power_charge_up"));
	public static class_3414 ANCIENT_HAMMER_SLAM = new class_3414(new class_2960("gilded_doom", "ancient_hammer_slam"));
	public static class_3414 ENCHANTMENT_TORRENT = new class_3414(new class_2960("gilded_doom", "enchantment_torrent"));

	public static void load() {
		class_2378.method_10230(class_2378.field_11156, new class_2960("gilded_doom", "got_any_grapes"), GOT_ANY_GRAPES);
		class_2378.method_10230(class_2378.field_11156, new class_2960("gilded_doom", "got_any_glue"), GOT_ANY_GLUE);
		class_2378.method_10230(class_2378.field_11156, new class_2960("gilded_doom", "ultimate_power_charge_up"), ULTIMATE_POWER_CHARGE_UP);
		class_2378.method_10230(class_2378.field_11156, new class_2960("gilded_doom", "ancient_hammer_slam"), ANCIENT_HAMMER_SLAM);
		class_2378.method_10230(class_2378.field_11156, new class_2960("gilded_doom", "enchantment_torrent"), ENCHANTMENT_TORRENT);
	}
}
