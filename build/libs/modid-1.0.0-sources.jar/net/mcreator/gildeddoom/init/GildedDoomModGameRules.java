
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;

public class GildedDoomModGameRules {
	public static class_1928.class_4313<class_1928.class_4310> ALLOWGILDEDBANISHMENT;
	public static class_1928.class_4313<class_1928.class_4310> BOOK_UNLOCKED;
	public static class_1928.class_4313<class_1928.class_4310> DO_REAL_BANS;

	public static void load() {
		ALLOWGILDEDBANISHMENT = GameRuleRegistry.register("allowgildedbanishment", class_1928.class_5198.field_24094, GameRuleFactory.createBooleanRule(false));
		BOOK_UNLOCKED = GameRuleRegistry.register("book_unlocked", class_1928.class_5198.field_24100, GameRuleFactory.createBooleanRule(false));
		DO_REAL_BANS = GameRuleRegistry.register("do_real_bans", class_1928.class_5198.field_24094, GameRuleFactory.createBooleanRule(true));
	}
}
