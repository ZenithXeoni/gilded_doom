
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.mcreator.gildeddoom.entity.SavageDuckEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.mcreator.gildeddoom.entity.DuckEntity;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

public class GildedDoomModEntities {
	public static class_1299<DuckEntity> DUCK;
	public static class_1299<SavageDuckEntity> SAVAGE_DUCK;

	public static void load() {
		DUCK = class_2378.method_10230(class_2378.field_11145, new class_2960(GildedDoomMod.MODID, "duck"),
				FabricEntityTypeBuilder.create(class_1311.field_6294, DuckEntity::new).dimensions(new class_4048(0.4f, 0.7f, true)).fireImmune().trackRangeBlocks(64).forceTrackedVelocityUpdates(true).trackedUpdateRate(3).build());
		DuckEntity.init();
		FabricDefaultAttributeRegistry.register(DUCK, DuckEntity.createAttributes());
		SAVAGE_DUCK = class_2378.method_10230(class_2378.field_11145, new class_2960(GildedDoomMod.MODID, "savage_duck"),
				FabricEntityTypeBuilder.create(class_1311.field_6302, SavageDuckEntity::new).dimensions(new class_4048(0.4f, 0.7f, true)).fireImmune().trackRangeBlocks(64).forceTrackedVelocityUpdates(true).trackedUpdateRate(3).build());
		SavageDuckEntity.init();
		FabricDefaultAttributeRegistry.register(SAVAGE_DUCK, SavageDuckEntity.createAttributes());
	}

	private static <T extends class_1297> class_1299<T> createArrowEntityType(class_1299.class_4049<T> factory) {
		return FabricEntityTypeBuilder.create(class_1311.field_17715, factory).dimensions(class_4048.method_18385(0.5f, 0.5f)).trackRangeBlocks(1).trackedUpdateRate(64).build();
	}
}
