
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.mcreator.gildeddoom.block.PurgatoryStoneStairsBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.mcreator.gildeddoom.block.PurgatoryStoneSlabBlock;
import net.mcreator.gildeddoom.block.PurgatoryStoneBlock;
import net.mcreator.gildeddoom.block.PurgatoryNyliumBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneWallBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneStairsBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneSlabBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneBricksBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneBrickWallBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneBrickStairsBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneBrickSlabBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryStoneBlock;
import net.mcreator.gildeddoom.block.PolishedPurgatoryFenceBlock;
import net.mcreator.gildeddoom.block.IronInfusedPurgatoryStoneSlabBlock;
import net.mcreator.gildeddoom.block.IronInfusedPurgatoryStoneBlock;
import net.mcreator.gildeddoom.block.GildedPurgatoryStoneSlabBlock;
import net.mcreator.gildeddoom.block.GildedPurgatoryStoneBlock;
import net.mcreator.gildeddoom.block.DemenaniteOreBlock;
import net.mcreator.gildeddoom.block.CrackedPurgatoryStoneBrickWallBlock;
import net.mcreator.gildeddoom.block.CrackedPolishedPurgatoryStoneStairsBlock;
import net.mcreator.gildeddoom.block.CrackedPolishedPurgatoryBricksBlock;
import net.mcreator.gildeddoom.block.CrackedPolishedPurgatoryBrickSlabBlock;
import net.mcreator.gildeddoom.block.ChiseledPolishedPurgatoryBricksBlock;
import net.mcreator.gildeddoom.block.BleedingObsidanBlock;
import net.mcreator.gildeddoom.GildedDoomMod;

public class GildedDoomModBlocks {
	public static class_2248 PURGATORY_NYLIUM;
	public static class_2248 PURGATORY_STONE;
	public static class_2248 POLISHED_PURGATORY_STONE;
	public static class_2248 POLISHED_PURGATORY_STONE_BRICKS;
	public static class_2248 CRACKED_POLISHED_PURGATORY_BRICKS;
	public static class_2248 CHISELED_POLISHED_PURGATORY_BRICKS;
	public static class_2248 GILDED_PURGATORY_STONE;
	public static class_2248 IRON_INFUSED_PURGATORY_STONE;
	public static class_2248 POLISHED_PURGATORY_STONE_BRICK_WALL;
	public static class_2248 POLISHED_PURGATORY_STONE_WALL;
	public static class_2248 CRACKED_PURGATORY_STONE_BRICK_WALL;
	public static class_2248 PURGATORY_STONE_SLAB;
	public static class_2248 POLISHED_PURGATORY_STONE_SLAB;
	public static class_2248 POLISHED_PURGATORY_STONE_BRICK_SLAB;
	public static class_2248 CRACKED_POLISHED_PURGATORY_BRICK_SLAB;
	public static class_2248 PURGATORY_STONE_STAIRS;
	public static class_2248 POLISHED_PURGATORY_STONE_STAIRS;
	public static class_2248 POLISHED_PURGATORY_STONE_BRICK_STAIRS;
	public static class_2248 CRACKED_POLISHED_PURGATORY_STONE_STAIRS;
	public static class_2248 GILDED_PURGATORY_STONE_SLAB;
	public static class_2248 IRON_INFUSED_PURGATORY_STONE_SLAB;
	public static class_2248 POLISHED_PURGATORY_FENCE;
	public static class_2248 BLEEDING_OBSIDAN;
	public static class_2248 DEMENANITE_ORE;

	public static void load() {
		PURGATORY_NYLIUM = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "purgatory_nylium"), new PurgatoryNyliumBlock());
		PURGATORY_STONE = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "purgatory_stone"), new PurgatoryStoneBlock());
		POLISHED_PURGATORY_STONE = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone"), new PolishedPurgatoryStoneBlock());
		POLISHED_PURGATORY_STONE_BRICKS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_bricks"), new PolishedPurgatoryStoneBricksBlock());
		CRACKED_POLISHED_PURGATORY_BRICKS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "cracked_polished_purgatory_bricks"), new CrackedPolishedPurgatoryBricksBlock());
		CHISELED_POLISHED_PURGATORY_BRICKS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "chiseled_polished_purgatory_bricks"), new ChiseledPolishedPurgatoryBricksBlock());
		GILDED_PURGATORY_STONE = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "gilded_purgatory_stone"), new GildedPurgatoryStoneBlock());
		IRON_INFUSED_PURGATORY_STONE = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "iron_infused_purgatory_stone"), new IronInfusedPurgatoryStoneBlock());
		POLISHED_PURGATORY_STONE_BRICK_WALL = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_brick_wall"), new PolishedPurgatoryStoneBrickWallBlock());
		POLISHED_PURGATORY_STONE_WALL = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_wall"), new PolishedPurgatoryStoneWallBlock());
		CRACKED_PURGATORY_STONE_BRICK_WALL = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "cracked_purgatory_stone_brick_wall"), new CrackedPurgatoryStoneBrickWallBlock());
		PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "purgatory_stone_slab"), new PurgatoryStoneSlabBlock());
		POLISHED_PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_slab"), new PolishedPurgatoryStoneSlabBlock());
		POLISHED_PURGATORY_STONE_BRICK_SLAB = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_brick_slab"), new PolishedPurgatoryStoneBrickSlabBlock());
		CRACKED_POLISHED_PURGATORY_BRICK_SLAB = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "cracked_polished_purgatory_brick_slab"), new CrackedPolishedPurgatoryBrickSlabBlock());
		PURGATORY_STONE_STAIRS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "purgatory_stone_stairs"), new PurgatoryStoneStairsBlock());
		POLISHED_PURGATORY_STONE_STAIRS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_stairs"), new PolishedPurgatoryStoneStairsBlock());
		POLISHED_PURGATORY_STONE_BRICK_STAIRS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_brick_stairs"), new PolishedPurgatoryStoneBrickStairsBlock());
		CRACKED_POLISHED_PURGATORY_STONE_STAIRS = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "cracked_polished_purgatory_stone_stairs"), new CrackedPolishedPurgatoryStoneStairsBlock());
		GILDED_PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "gilded_purgatory_stone_slab"), new GildedPurgatoryStoneSlabBlock());
		IRON_INFUSED_PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "iron_infused_purgatory_stone_slab"), new IronInfusedPurgatoryStoneSlabBlock());
		POLISHED_PURGATORY_FENCE = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "polished_purgatory_fence"), new PolishedPurgatoryFenceBlock());
		BLEEDING_OBSIDAN = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "bleeding_obsidan"), new BleedingObsidanBlock());
		DEMENANITE_ORE = class_2378.method_10230(class_2378.field_11146, new class_2960(GildedDoomMod.MODID, "demenanite_ore"), new DemenaniteOreBlock());
	}

	public static void clientLoad() {
		PurgatoryNyliumBlock.clientInit();
		PurgatoryStoneBlock.clientInit();
		PolishedPurgatoryStoneBlock.clientInit();
		PolishedPurgatoryStoneBricksBlock.clientInit();
		CrackedPolishedPurgatoryBricksBlock.clientInit();
		ChiseledPolishedPurgatoryBricksBlock.clientInit();
		GildedPurgatoryStoneBlock.clientInit();
		IronInfusedPurgatoryStoneBlock.clientInit();
		PolishedPurgatoryStoneBrickWallBlock.clientInit();
		PolishedPurgatoryStoneWallBlock.clientInit();
		CrackedPurgatoryStoneBrickWallBlock.clientInit();
		PurgatoryStoneSlabBlock.clientInit();
		PolishedPurgatoryStoneSlabBlock.clientInit();
		PolishedPurgatoryStoneBrickSlabBlock.clientInit();
		CrackedPolishedPurgatoryBrickSlabBlock.clientInit();
		PurgatoryStoneStairsBlock.clientInit();
		PolishedPurgatoryStoneStairsBlock.clientInit();
		PolishedPurgatoryStoneBrickStairsBlock.clientInit();
		CrackedPolishedPurgatoryStoneStairsBlock.clientInit();
		GildedPurgatoryStoneSlabBlock.clientInit();
		IronInfusedPurgatoryStoneSlabBlock.clientInit();
		PolishedPurgatoryFenceBlock.clientInit();
		BleedingObsidanBlock.clientInit();
		DemenaniteOreBlock.clientInit();
	}
}
