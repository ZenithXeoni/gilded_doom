
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.mcreator.gildeddoom.enchantment.TorrentEnchantment;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.mcreator.gildeddoom.enchantment.KnockoutEnchantment;
import net.mcreator.gildeddoom.enchantment.FortitudeEnchantment;
import net.mcreator.gildeddoom.GildedDoomMod;

public class GildedDoomModEnchantments {
	public static class_1887 TORRENT;
	public static class_1887 FORTITUDE;
	public static class_1887 KNOCKOUT;

	public static void load() {
		TORRENT = class_2378.method_10230(class_2378.field_11160, new class_2960(GildedDoomMod.MODID, "torrent"), new TorrentEnchantment());
		FORTITUDE = class_2378.method_10230(class_2378.field_11160, new class_2960(GildedDoomMod.MODID, "fortitude"), new FortitudeEnchantment());
		KNOCKOUT = class_2378.method_10230(class_2378.field_11160, new class_2960(GildedDoomMod.MODID, "knockout"), new KnockoutEnchantment());
	}
}
