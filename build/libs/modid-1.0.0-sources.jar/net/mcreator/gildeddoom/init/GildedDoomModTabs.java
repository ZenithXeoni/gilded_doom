
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class GildedDoomModTabs {
	public static class_1761 TAB_GILDED_DOOM;
	public static class_1761 TAB_PURGATORY_TAB;

	public static void load() {
		TAB_GILDED_DOOM = FabricItemGroupBuilder.create(new class_2960("gilded_doom", "gilded_doom")).icon(() -> new class_1799(GildedDoomModItems.GILDED_CONTRACT)).build();
		TAB_PURGATORY_TAB = FabricItemGroupBuilder.create(new class_2960("gilded_doom", "purgatory_tab")).icon(() -> new class_1799(GildedDoomModItems.PURGATORY_AMALGAM)).build();
	}
}
