
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gildeddoom.init;

import net.mcreator.gildeddoom.item.WitheringTomeItem;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.mcreator.gildeddoom.item.WarpedAmalgamItem;
import net.mcreator.gildeddoom.item.TrackingTomeItem;
import net.mcreator.gildeddoom.item.SoulforgedHammerItem;
import net.mcreator.gildeddoom.item.PurgatoryAmalgamItem;
import net.mcreator.gildeddoom.item.IronHammerItem;
import net.mcreator.gildeddoom.item.InfernalScrapItem;
import net.mcreator.gildeddoom.item.InfernalCoreItem;
import net.mcreator.gildeddoom.item.ImmunityTomeItem;
import net.mcreator.gildeddoom.item.HellforgedHammerItem;
import net.mcreator.gildeddoom.item.GildedIngotItem;
import net.mcreator.gildeddoom.item.GildedCoreItem;
import net.mcreator.gildeddoom.item.GildedContractItem;
import net.mcreator.gildeddoom.item.GildedBruteItem;
import net.mcreator.gildeddoom.item.GildedBanisherItem;
import net.mcreator.gildeddoom.item.FreeMeItem;
import net.mcreator.gildeddoom.item.DemonicDustItem;
import net.mcreator.gildeddoom.item.CleansingTomeItem;
import net.mcreator.gildeddoom.item.ChippedAmalgamItem;
import net.mcreator.gildeddoom.item.BrutalTomeItem;
import net.mcreator.gildeddoom.item.BookOfGildedBanishmentItem;
import net.mcreator.gildeddoom.item.BloodGrapesItem;
import net.mcreator.gildeddoom.item.AncientHammerItem;
import net.mcreator.gildeddoom.GildedDoomMod;

public class GildedDoomModItems {
	public static class_1792 IRON_HAMMER;
	public static class_1792 ANCIENT_HAMMER;
	public static class_1792 GILDED_BANISHER;
	public static class_1792 HELLFORGED_HAMMER;
	public static class_1792 SOULFORGED_HAMMER;
	public static class_1792 GILDED_CONTRACT;
	public static class_1792 BRUTAL_TOME;
	public static class_1792 WITHERING_TOME;
	public static class_1792 INFERNAL_SCRAP;
	public static class_1792 INFERNAL_CORE;
	public static class_1792 GILDED_CORE;
	public static class_1792 PURGATORY_AMALGAM;
	public static class_1792 PURGATORY_NYLIUM;
	public static class_1792 PURGATORY_STONE;
	public static class_1792 POLISHED_PURGATORY_STONE;
	public static class_1792 POLISHED_PURGATORY_STONE_BRICKS;
	public static class_1792 CRACKED_POLISHED_PURGATORY_BRICKS;
	public static class_1792 CHISELED_POLISHED_PURGATORY_BRICKS;
	public static class_1792 GILDED_PURGATORY_STONE;
	public static class_1792 IRON_INFUSED_PURGATORY_STONE;
	public static class_1792 DUCK_SPAWN_EGG;
	public static class_1792 SAVAGE_DUCK_SPAWN_EGG;
	public static class_1792 IMMUNITY_TOME;
	public static class_1792 GILDED_INGOT;
	public static class_1792 GILDED_BRUTE_HELMET;
	public static class_1792 GILDED_BRUTE_CHESTPLATE;
	public static class_1792 GILDED_BRUTE_LEGGINGS;
	public static class_1792 GILDED_BRUTE_BOOTS;
	public static class_1792 TRACKING_TOME;
	public static class_1792 WARPED_AMALGAM;
	public static class_1792 FREE_ME;
	public static class_1792 CLEANSING_TOME;
	public static class_1792 POLISHED_PURGATORY_STONE_BRICK_WALL;
	public static class_1792 POLISHED_PURGATORY_STONE_WALL;
	public static class_1792 CRACKED_PURGATORY_STONE_BRICK_WALL;
	public static class_1792 PURGATORY_STONE_SLAB;
	public static class_1792 POLISHED_PURGATORY_STONE_SLAB;
	public static class_1792 POLISHED_PURGATORY_STONE_BRICK_SLAB;
	public static class_1792 CRACKED_POLISHED_PURGATORY_BRICK_SLAB;
	public static class_1792 PURGATORY_STONE_STAIRS;
	public static class_1792 POLISHED_PURGATORY_STONE_STAIRS;
	public static class_1792 POLISHED_PURGATORY_STONE_BRICK_STAIRS;
	public static class_1792 CRACKED_POLISHED_PURGATORY_STONE_STAIRS;
	public static class_1792 GILDED_PURGATORY_STONE_SLAB;
	public static class_1792 IRON_INFUSED_PURGATORY_STONE_SLAB;
	public static class_1792 POLISHED_PURGATORY_FENCE;
	public static class_1792 BLOOD_GRAPES;
	public static class_1792 CHIPPED_AMALGAM;
	public static class_1792 BLEEDING_OBSIDAN;
	public static class_1792 DEMENANITE_ORE;
	public static class_1792 DEMONIC_DUST;
	public static class_1792 BOOK_OF_GILDED_BANISHMENT;

	public static void load() {
		IRON_HAMMER = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "iron_hammer"), new IronHammerItem());
		ANCIENT_HAMMER = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "ancient_hammer"), new AncientHammerItem());
		GILDED_BANISHER = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_banisher"), new GildedBanisherItem());
		HELLFORGED_HAMMER = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "hellforged_hammer"), new HellforgedHammerItem());
		SOULFORGED_HAMMER = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "soulforged_hammer"), new SoulforgedHammerItem());
		GILDED_CONTRACT = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_contract"), new GildedContractItem());
		BRUTAL_TOME = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "brutal_tome"), new BrutalTomeItem());
		WITHERING_TOME = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "withering_tome"), new WitheringTomeItem());
		INFERNAL_SCRAP = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "infernal_scrap"), new InfernalScrapItem());
		INFERNAL_CORE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "infernal_core"), new InfernalCoreItem());
		GILDED_CORE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_core"), new GildedCoreItem());
		PURGATORY_AMALGAM = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "purgatory_amalgam"), new PurgatoryAmalgamItem());
		PURGATORY_NYLIUM = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "purgatory_nylium"), new class_1747(GildedDoomModBlocks.PURGATORY_NYLIUM, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		PURGATORY_STONE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "purgatory_stone"), new class_1747(GildedDoomModBlocks.PURGATORY_STONE, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE_BRICKS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_bricks"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_BRICKS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		CRACKED_POLISHED_PURGATORY_BRICKS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "cracked_polished_purgatory_bricks"),
				new class_1747(GildedDoomModBlocks.CRACKED_POLISHED_PURGATORY_BRICKS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		CHISELED_POLISHED_PURGATORY_BRICKS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "chiseled_polished_purgatory_bricks"),
				new class_1747(GildedDoomModBlocks.CHISELED_POLISHED_PURGATORY_BRICKS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		GILDED_PURGATORY_STONE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_purgatory_stone"),
				new class_1747(GildedDoomModBlocks.GILDED_PURGATORY_STONE, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		IRON_INFUSED_PURGATORY_STONE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "iron_infused_purgatory_stone"),
				new class_1747(GildedDoomModBlocks.IRON_INFUSED_PURGATORY_STONE, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		DUCK_SPAWN_EGG = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "duck_spawn_egg"), new class_1826(GildedDoomModEntities.DUCK, -13312, -13312, new class_1792.class_1793().method_7892(class_1761.field_7932)));
		SAVAGE_DUCK_SPAWN_EGG = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "savage_duck_spawn_egg"),
				new class_1826(GildedDoomModEntities.SAVAGE_DUCK, -3407821, -10092544, new class_1792.class_1793().method_7892(class_1761.field_7932)));
		IMMUNITY_TOME = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "immunity_tome"), new ImmunityTomeItem());
		GILDED_INGOT = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_ingot"), new GildedIngotItem());
		GILDED_BRUTE_HELMET = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_brute_helmet"), new GildedBruteItem.Helmet());
		GILDED_BRUTE_CHESTPLATE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_brute_chestplate"), new GildedBruteItem.Chestplate());
		GILDED_BRUTE_LEGGINGS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_brute_leggings"), new GildedBruteItem.Leggings());
		GILDED_BRUTE_BOOTS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_brute_boots"), new GildedBruteItem.Boots());
		TRACKING_TOME = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "tracking_tome"), new TrackingTomeItem());
		WARPED_AMALGAM = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "warped_amalgam"), new WarpedAmalgamItem());
		FREE_ME = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "free_me"), new FreeMeItem());
		CLEANSING_TOME = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "cleansing_tome"), new CleansingTomeItem());
		POLISHED_PURGATORY_STONE_BRICK_WALL = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_brick_wall"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_BRICK_WALL, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE_WALL = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_wall"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_WALL, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		CRACKED_PURGATORY_STONE_BRICK_WALL = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "cracked_purgatory_stone_brick_wall"),
				new class_1747(GildedDoomModBlocks.CRACKED_PURGATORY_STONE_BRICK_WALL, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "purgatory_stone_slab"),
				new class_1747(GildedDoomModBlocks.PURGATORY_STONE_SLAB, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_slab"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_SLAB, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE_BRICK_SLAB = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_brick_slab"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_BRICK_SLAB, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		CRACKED_POLISHED_PURGATORY_BRICK_SLAB = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "cracked_polished_purgatory_brick_slab"),
				new class_1747(GildedDoomModBlocks.CRACKED_POLISHED_PURGATORY_BRICK_SLAB, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		PURGATORY_STONE_STAIRS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "purgatory_stone_stairs"),
				new class_1747(GildedDoomModBlocks.PURGATORY_STONE_STAIRS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE_STAIRS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_stairs"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_STAIRS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_STONE_BRICK_STAIRS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_stone_brick_stairs"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_BRICK_STAIRS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		CRACKED_POLISHED_PURGATORY_STONE_STAIRS = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "cracked_polished_purgatory_stone_stairs"),
				new class_1747(GildedDoomModBlocks.CRACKED_POLISHED_PURGATORY_STONE_STAIRS, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		GILDED_PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "gilded_purgatory_stone_slab"),
				new class_1747(GildedDoomModBlocks.GILDED_PURGATORY_STONE_SLAB, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		IRON_INFUSED_PURGATORY_STONE_SLAB = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "iron_infused_purgatory_stone_slab"),
				new class_1747(GildedDoomModBlocks.IRON_INFUSED_PURGATORY_STONE_SLAB, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		POLISHED_PURGATORY_FENCE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "polished_purgatory_fence"),
				new class_1747(GildedDoomModBlocks.POLISHED_PURGATORY_FENCE, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		BLOOD_GRAPES = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "blood_grapes"), new BloodGrapesItem());
		CHIPPED_AMALGAM = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "chipped_amalgam"), new ChippedAmalgamItem());
		BLEEDING_OBSIDAN = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "bleeding_obsidan"), new class_1747(GildedDoomModBlocks.BLEEDING_OBSIDAN, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		DEMENANITE_ORE = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "demenanite_ore"), new class_1747(GildedDoomModBlocks.DEMENANITE_ORE, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB)));
		DEMONIC_DUST = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "demonic_dust"), new DemonicDustItem());
		BOOK_OF_GILDED_BANISHMENT = class_2378.method_10230(class_2378.field_11142, new class_2960(GildedDoomMod.MODID, "book_of_gilded_banishment"), new BookOfGildedBanishmentItem());
	}
}
