package net.mcreator.gildeddoom.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.minecraft.class_4317;
import java.util.ArrayList;

import com.google.common.collect.Lists;

@Mixin(class_4317.class)
public abstract class GildedDoomModRepairItemRecipeMixin {
	@Inject(method = "assemble", at = @At("HEAD"), cancellable = true)
	public void assemble(class_1715 craftingContainer, CallbackInfoReturnable<class_1799> cir) {
		class_1799 itemStack3;
		class_1799 itemStack;
		ArrayList<class_1799> list = Lists.newArrayList();
		for (int i = 0; i < craftingContainer.method_5439(); ++i) {
			class_1799 itemStack2;
			itemStack = craftingContainer.method_5438(i);
			if (itemStack.method_7960())
				continue;
			list.add(itemStack);
		}
		if ((itemStack3 = (class_1799) list.get(0)).method_31574((GildedDoomModItems.PURGATORY_AMALGAM))) {
			cir.setReturnValue(class_1799.field_8037);
		}
	}
}
