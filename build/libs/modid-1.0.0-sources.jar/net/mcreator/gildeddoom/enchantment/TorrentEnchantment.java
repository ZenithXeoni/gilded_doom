
package net.mcreator.gildeddoom.enchantment;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.mcreator.gildeddoom.init.GildedDoomModEnchantments;

public class TorrentEnchantment extends class_1887 {
	public TorrentEnchantment(class_1304... slots) {
		super(class_1887.class_1888.field_9087, class_1886.field_9082, slots);
	}

	@Override
	protected boolean method_8180(class_1887 ench) {
		if (ench == GildedDoomModEnchantments.FORTITUDE)
			return true;
		if (ench == GildedDoomModEnchantments.KNOCKOUT)
			return true;
		return false;
	}

	@Override
	public boolean method_8192(class_1799 stack) {
		if (stack.method_7909() == GildedDoomModItems.IRON_HAMMER)
			return true;
		if (stack.method_7909() == GildedDoomModItems.HELLFORGED_HAMMER)
			return true;
		if (stack.method_7909() == GildedDoomModItems.SOULFORGED_HAMMER)
			return true;
		if (stack.method_7909() == GildedDoomModItems.ANCIENT_HAMMER)
			return true;
		if (stack.method_7909() == GildedDoomModItems.GILDED_BANISHER)
			return true;
		return false;
	}
}
