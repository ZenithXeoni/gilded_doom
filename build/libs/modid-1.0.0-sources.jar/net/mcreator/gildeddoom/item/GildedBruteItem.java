
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.GildedBruteLeggingsTickEventProcedure;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.mcreator.gildeddoom.procedures.GildedBruteHelmetTickEventProcedure;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;
import net.mcreator.gildeddoom.init.GildedDoomModItems;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;

public abstract class GildedBruteItem extends class_1738 {
	public GildedBruteItem(class_1304 slot, class_1792.class_1793 properties) {
		super(new class_1741() {
			@Override
			public int method_7696(class_1304 slot) {
				return new int[]{13, 15, 16, 11}[slot.method_5927()] * 40;
			}

			@Override
			public int method_7697(class_1304 slot) {
				return new int[]{3, 6, 6, 2}[slot.method_5927()];
			}

			@Override
			public int method_7699() {
				return 15;
			}

			@Override
			public class_3414 method_7698() {
				return class_3417.field_21866;
			}

			@Override
			public class_1856 method_7695() {
				return class_1856.method_8101(new class_1799(GildedDoomModItems.GILDED_INGOT), new class_1799(class_1802.field_22020));
			}

			@Environment(EnvType.CLIENT)
			@Override
			public String method_7694() {
				return "gilded_brute_armor_";
			}

			@Override
			public float method_7700() {
				return 3f;
			}

			@Override
			public float method_24355() {
				return 0.1f;
			}
		}, slot, properties);
	}

	public static class Helmet extends GildedBruteItem {

		public Helmet() {
			super(class_1304.field_6169, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
		}

		@Override
		public void method_7888(class_1799 itemstack, class_1937 world, class_1297 entity, int slotinv, boolean selected) {
			double unique = Math.random();
			class_1799 stack = entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037;
			if (stack.method_7909() == (itemstack).method_7909()) {
				if (stack.method_7948().method_10574("_id") != unique)
					stack.method_7948().method_10549("_id", unique);
				if (itemstack.method_7948().method_10574("_id") == unique)
					GildedBruteHelmetTickEventProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
			}
		}
	}

	public static class Chestplate extends GildedBruteItem {

		public Chestplate() {
			super(class_1304.field_6174, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
			list.add(class_2561.method_43470("Built-in Thorns III~"));
		}
	}

	public static class Leggings extends GildedBruteItem {

		public Leggings() {
			super(class_1304.field_6172, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
		}

		@Override
		public void method_7888(class_1799 itemstack, class_1937 world, class_1297 entity, int slotinv, boolean selected) {
			double unique = Math.random();
			class_1799 stack = entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037;
			if (stack.method_7909() == (itemstack).method_7909()) {
				if (stack.method_7948().method_10574("_id") != unique)
					stack.method_7948().method_10549("_id", unique);
				if (itemstack.method_7948().method_10574("_id") == unique)
					GildedBruteLeggingsTickEventProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
			}
		}
	}

	public static class Boots extends GildedBruteItem {

		public Boots() {
			super(class_1304.field_6166, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
		}

	}
}
