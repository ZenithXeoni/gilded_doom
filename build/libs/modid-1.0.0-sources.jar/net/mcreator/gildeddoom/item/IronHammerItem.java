
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.HammerEnchantsProcedure;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;

public class IronHammerItem extends class_1810 {
	public IronHammerItem() {
		super(new class_1832() {
			public int method_8025() {
				return 1200;
			}

			public float method_8027() {
				return 9f;
			}

			public float method_8028() {
				return 5f;
			}

			public int method_8024() {
				return 2;
			}

			public int method_8026() {
				return 15;
			}

			public class_1856 method_8023() {
				return class_1856.method_8101(new class_1799(class_1802.field_8620));
			}
		}, 1, -3f, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM));
	}

	@Override
	public boolean method_7873(class_1799 itemstack, class_1309 entity, class_1309 sourceentity) {
		boolean retval = super.method_7873(itemstack, entity, sourceentity);
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();
		class_1937 world = entity.field_6002;
		HammerEnchantsProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("sourceentity", sourceentity).build());
		return retval;
	}
}
