
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.FreeMeRightclickedProcedure;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;

import java.util.List;

public class FreeMeItem extends class_1792 {
	public FreeMeItem() {
		super(new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_7889(64).method_7894(class_1814.field_8906));
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
		list.add(class_2561.method_43470("Gives you all the Soul Requirements - Admin Only"));
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 entity, class_1268 hand) {
		class_1271<class_1799> ar = super.method_7836(world, entity, hand);
		class_1799 itemstack = ar.method_5466();
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();

		FreeMeRightclickedProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("itemstack", itemstack).build());
		return ar;
	}
}
