
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.mcreator.gildeddoom.procedures.BookofGildedBanishmentItemInInventoryTickProcedure;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class BookOfGildedBanishmentItem extends class_1810 {
    public BookOfGildedBanishmentItem() {
        super(new class_1832() {
            public int method_8025() {
                return 250;
            }

            public float method_8027() {
                return 4f;
            }

            public float method_8028() {
                return 2f;
            }

            public int method_8024() {
                return 1;
            }

            public int method_8026() {
                return 25;
            }

            public class_1856 method_8023() {
                return class_1856.method_8101(new class_1799(class_2246.field_23880));
            }
        }, 1, -2f, new class_1792.class_1793().method_7892(class_1761.field_7930).method_24359());
    }

    @Override
    public void method_7888(class_1799 itemstack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        super.method_7888(itemstack, world, entity, slot, selected);
        BookofGildedBanishmentItemInInventoryTickProcedure
                .execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("x", entity.method_23317()).put("y", entity.method_23318()).put("z", entity.method_23321()).put("world", world).put("entity", entity).build());
    }

    @Override
    public boolean method_7873(class_1799 itemstack, class_1309 target, class_1309 attacker) {
        class_1937 world = attacker.field_6002;
        if (attacker instanceof class_1657 player) {
            // Check for Critical Hit
            if (player.field_6017 > 0.0F && !player.method_24828() && !player.method_6101() && !player.method_5799() && !player.method_6059(class_1294.field_5919) && !player.method_5765()) {

                // 1. Apply Gilded Stasis
                target.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_STASIS, 60, 0));

                // 2. Play Door Breaking Sound
                world.method_43128(null, target.method_23317(), target.method_23318(), target.method_23321(),
                        class_3417.field_14742, class_3419.field_15248, 1.0F, 0.5F);
                world.method_43128(null, target.method_23317(), target.method_23318(), target.method_23321(),
                        class_3417.field_14833, class_3419.field_15248, 1.0F, 0.5F);

                // 3. Blackstone Particle Effects
                if (!world.method_8608() && world instanceof class_3218 serverWorld) {
                    // This creates a burst of particles based on the Gilded Blackstone block
                    serverWorld.method_14199(new class_2388(class_2398.field_11217, class_2246.field_23880.method_9564()),
                            target.method_23317(), target.method_23318() + 1, target.method_23321(), 20, 0.3, 0.3, 0.3, 0.15);
                }
            }
        }
        return super.method_7873(itemstack, target, attacker);
    }
}