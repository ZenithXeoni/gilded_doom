
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.init.GildedDoomModTabs;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;

public class GildedIngotItem extends class_1792 {
	public GildedIngotItem() {
		super(new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_7889(64).method_24359().method_7894(class_1814.field_8906));
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}
}
