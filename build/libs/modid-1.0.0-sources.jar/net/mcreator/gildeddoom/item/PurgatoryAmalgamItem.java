
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.PurgatoryAmalgamRightclickedRealProcedure;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;

public class PurgatoryAmalgamItem extends class_1792 {
	public PurgatoryAmalgamItem() {
		super(new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB).method_7889(1).method_7894(class_1814.field_8907));
	}

	@Override
	public boolean method_7857() {
		return true;
	}

	@Override
	public class_1799 getRecipeRemainder(class_1799 itemstack) {
		return new class_1799(class_1802.field_8634);
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 entity, class_1268 hand) {
		class_1271<class_1799> ar = super.method_7836(world, entity, hand);
		class_1799 itemstack = ar.method_5466();
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();

		PurgatoryAmalgamRightclickedRealProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("itemstack", itemstack).build());
		return ar;
	}
}
