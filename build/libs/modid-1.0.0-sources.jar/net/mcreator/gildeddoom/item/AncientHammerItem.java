
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.AncientHammerRightclickedProcedure;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.mcreator.gildeddoom.procedures.AncientHammerLivingEntityIsHitWithToolProcedure;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;

public class AncientHammerItem extends class_1810 {
	public AncientHammerItem() {
		super(new class_1832() {
			public int method_8025() {
				return 1561;
			}

			public float method_8027() {
				return 10f;
			}

			public float method_8028() {
				return 7f;
			}

			public int method_8024() {
				return 4;
			}

			public int method_8026() {
				return 22;
			}

			public class_1856 method_8023() {
				return class_1856.method_8101(new class_1799(class_1802.field_22021));
			}
		}, 1, -3f, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
	}

	@Override
	public boolean method_7873(class_1799 itemstack, class_1309 entity, class_1309 sourceentity) {
		boolean retval = super.method_7873(itemstack, entity, sourceentity);
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();
		class_1937 world = entity.field_6002;
		AncientHammerLivingEntityIsHitWithToolProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("sourceentity", sourceentity).build());
		return retval;
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 entity, class_1268 hand) {
		class_1271<class_1799> ar = super.method_7836(world, entity, hand);
		AncientHammerRightclickedProcedure
				.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("x", entity.method_23317()).put("y", entity.method_23318()).put("z", entity.method_23321()).put("world", world).put("entity", entity).put("itemstack", ar.method_5466()).build());
		return ar;
	}
}
