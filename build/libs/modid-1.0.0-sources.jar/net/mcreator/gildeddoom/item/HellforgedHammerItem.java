
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.HellforgedHammerToolInHandTickProcedure;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.mcreator.gildeddoom.procedures.HellforgedHammerLivingEntityIsHitWithToolProcedure;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;
import net.mcreator.gildeddoom.init.GildedDoomModItems;

public class HellforgedHammerItem extends class_1810 {
	public HellforgedHammerItem() {
		super(new class_1832() {
			public int method_8025() {
				return 2500;
			}

			public float method_8027() {
				return 11f;
			}

			public float method_8028() {
				return 8f;
			}

			public int method_8024() {
				return 4;
			}

			public int method_8026() {
				return 35;
			}

			public class_1856 method_8023() {
				return class_1856.method_8101(new class_1799(GildedDoomModItems.INFERNAL_SCRAP));
			}
		}, 1, -3f, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
	}

	@Override
	public boolean method_7873(class_1799 itemstack, class_1309 entity, class_1309 sourceentity) {
		boolean retval = super.method_7873(itemstack, entity, sourceentity);
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();
		class_1937 world = entity.field_6002;
		HellforgedHammerLivingEntityIsHitWithToolProcedure
				.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("sourceentity", sourceentity).build());
		return retval;
	}

	@Override
	public void method_7888(class_1799 itemstack, class_1937 world, class_1297 entity, int slot, boolean selected) {
		super.method_7888(itemstack, world, entity, slot, selected);
		if (selected)
			HellforgedHammerToolInHandTickProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("x", entity.method_23317()).put("y", entity.method_23318()).put("z", entity.method_23321()).put("world", world).build());
	}
}
