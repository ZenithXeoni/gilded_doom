
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.CleansingTomeRightclickedProcedure;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;

public class CleansingTomeItem extends class_1810 {
	public CleansingTomeItem() {
		super(new class_1832() {
			public int method_8025() {
				return 100;
			}

			public float method_8027() {
				return 6f;
			}

			public float method_8028() {
				return 2f;
			}

			public int method_8024() {
				return 1;
			}

			public int method_8026() {
				return 2;
			}

			public class_1856 method_8023() {
				return class_1856.field_9017;
			}
		}, 1, -3f, new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_24359());
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 entity, class_1268 hand) {
		class_1271<class_1799> ar = super.method_7836(world, entity, hand);
		CleansingTomeRightclickedProcedure
				.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("x", entity.method_23317()).put("y", entity.method_23318()).put("z", entity.method_23321()).put("world", world).put("entity", entity).put("itemstack", ar.method_5466()).build());
		return ar;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
		list.add(class_2561.method_43470("Beware: Thou shall still haunt."));
	}
}
