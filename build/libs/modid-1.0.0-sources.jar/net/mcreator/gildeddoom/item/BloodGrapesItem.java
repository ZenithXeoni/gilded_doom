
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.procedures.BloodGrapesPlayerFinishesUsingItemProcedure;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.mcreator.gildeddoom.init.GildedDoomModTabs;

import java.util.List;

public class BloodGrapesItem extends class_1792 {
	public BloodGrapesItem() {
		super(new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_PURGATORY_TAB).method_7889(64).method_7894(class_1814.field_8906).method_19265((new class_4174.class_4175()).method_19238(4).method_19237(0.3f)

				.method_19242()));
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 32;
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
		list.add(class_2561.method_43470("1% chance to cure 1 deathcurse"));
	}

	@Override
	public class_1799 method_7861(class_1799 itemstack, class_1937 world, class_1309 entity) {
		class_1799 retval = super.method_7861(itemstack, world, entity);
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();

		BloodGrapesPlayerFinishesUsingItemProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).build());
		return retval;
	}
}
