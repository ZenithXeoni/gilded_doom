
package net.mcreator.gildeddoom.item;

import net.mcreator.gildeddoom.init.GildedDoomModTabs;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;

public class WitheringTomeItem extends class_1792 {
	public WitheringTomeItem() {
		super(new class_1792.class_1793().method_7892(GildedDoomModTabs.TAB_GILDED_DOOM).method_7889(1).method_7894(class_1814.field_8907));
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}
}
