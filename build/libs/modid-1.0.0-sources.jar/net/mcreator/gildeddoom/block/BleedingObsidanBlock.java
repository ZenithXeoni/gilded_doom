
package net.mcreator.gildeddoom.block;

import net.mcreator.gildeddoom.init.GildedDoomModBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3614;
import net.minecraft.class_47;
import net.minecraft.class_4970;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class BleedingObsidanBlock extends class_2248 {
	public static class_4970.class_2251 PROPERTIES = FabricBlockSettings.method_9637(class_3614.field_15924).method_9626(class_2498.field_11544).method_9629(50f, 1200f);

	public BleedingObsidanBlock() {
		super(PROPERTIES);
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 15;
	}

	@Override
	public boolean method_9506(class_2680 state) {
		return true;
	}

	@Override
	public int method_9524(class_2680 blockstate, class_1922 blockAccess, class_2338 pos, class_2350 side) {
		return 5;
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_47.class_48 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(GildedDoomModBlocks.BLEEDING_OBSIDAN, class_1921.method_23577());
	}
}
