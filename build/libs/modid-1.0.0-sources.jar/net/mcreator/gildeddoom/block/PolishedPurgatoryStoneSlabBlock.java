
package net.mcreator.gildeddoom.block;

import net.mcreator.gildeddoom.init.GildedDoomModBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3614;
import net.minecraft.class_47;
import net.minecraft.class_4970;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class PolishedPurgatoryStoneSlabBlock extends class_2482 {
	public static class_4970.class_2251 PROPERTIES = FabricBlockSettings.method_9637(class_3614.field_15914).method_29292().method_9626(class_2498.field_11544).method_9629(1.5f, 10f).method_29292();

	public PolishedPurgatoryStoneSlabBlock() {
		super(PROPERTIES);
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_47.class_48 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, state.method_11654(field_11501) == class_2771.field_12682 ? 2 : 1));
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(GildedDoomModBlocks.POLISHED_PURGATORY_STONE_SLAB, class_1921.method_23577());
	}
}
