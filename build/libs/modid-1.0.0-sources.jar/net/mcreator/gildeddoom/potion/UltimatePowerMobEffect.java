
package net.mcreator.gildeddoom.potion;

import net.mcreator.gildeddoom.procedures.UltimatePowerOnEffectActiveTickProcedure;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_4081;

public class UltimatePowerMobEffect extends class_1291 {
	public UltimatePowerMobEffect() {
		super(class_4081.field_18271, -256);
	}

	@Override
	public String method_5567() {
		return "effect.gilded_doom.ultimate_power";
	}

	@Override
	public void method_5572(class_1309 entity, int amplifier) {
		class_1937 world = entity.field_6002;
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();

		UltimatePowerOnEffectActiveTickProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("entity", entity).build());
	}

	@Override
	public boolean method_5552(int duration, int amplifier) {
		return true;
	}
}
