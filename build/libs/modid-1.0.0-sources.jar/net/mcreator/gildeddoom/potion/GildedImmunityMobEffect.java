
package net.mcreator.gildeddoom.potion;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

public class GildedImmunityMobEffect extends class_1291 {
	public GildedImmunityMobEffect() {
		super(class_4081.field_18271, -13312);
	}

	@Override
	public String method_5567() {
		return "effect.gilded_doom.gilded_immunity";
	}

	@Override
	public boolean method_5552(int duration, int amplifier) {
		return true;
	}
}
