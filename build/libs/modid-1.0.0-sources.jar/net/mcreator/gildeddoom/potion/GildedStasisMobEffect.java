
package net.mcreator.gildeddoom.potion;

import net.mcreator.gildeddoom.procedures.GildedStasisOnEffectActiveTickProcedure;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_4081;

public class GildedStasisMobEffect extends class_1291 {
	public GildedStasisMobEffect() {
		super(class_4081.field_18272, -26368);
	}

	@Override
	public String method_5567() {
		return "effect.gilded_doom.gilded_stasis";
	}

	@Override
	public void method_5572(class_1309 entity, int amplifier) {
		class_1937 world = entity.field_6002;
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();

		GildedStasisOnEffectActiveTickProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
	}

	@Override
	public boolean method_5552(int duration, int amplifier) {
		return true;
	}
}
