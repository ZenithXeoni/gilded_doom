
package net.mcreator.gildeddoom.potion;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

public class GildedEmpowermentMobEffect extends class_1291 {
	public GildedEmpowermentMobEffect() {
		super(class_4081.field_18273, -13312);
	}

	@Override
	public String method_5567() {
		return "effect.gilded_doom.gilded_empowerment";
	}

	@Override
	public boolean method_5552(int duration, int amplifier) {
		return true;
	}
}
