
package net.mcreator.gildeddoom.potion;

import net.mcreator.gildeddoom.procedures.PendingDeathEffectExpiresProcedure;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_4081;
import net.minecraft.class_5131;

public class PendingDeathMobEffect extends class_1291 {
	public PendingDeathMobEffect() {
		super(class_4081.field_18272, -26368);
	}

	@Override
	public String method_5567() {
		return "effect.gilded_doom.pending_death";
	}

	@Override
	public void method_5562(class_1309 entity, class_5131 attributeMap, int amplifier) {
		super.method_5562(entity, attributeMap, amplifier);
		class_1937 world = entity.field_6002;
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();

		PendingDeathEffectExpiresProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).build());
	}

	@Override
	public boolean method_5552(int duration, int amplifier) {
		return true;
	}
}
