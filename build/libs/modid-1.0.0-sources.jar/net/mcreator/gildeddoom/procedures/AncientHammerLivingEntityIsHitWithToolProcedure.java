package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModSounds;
import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class AncientHammerLivingEntityIsHitWithToolProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure AncientHammerLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure AncientHammerLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure AncientHammerLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure AncientHammerLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure AncientHammerLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure AncientHammerLivingEntityIsHitWithTool!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		entity.method_18799(new class_243(0, (-20), 0));
		if (world instanceof class_1937 _level) {
			if (!_level.method_8608()) {
				_level.method_8396(null, new class_2338(x, y, z), GildedDoomModSounds.ANCIENT_HAMMER_SLAM, class_3419.field_15248, 1, 1);
			} else {
				_level.method_8486(x, y, z, GildedDoomModSounds.ANCIENT_HAMMER_SLAM, class_3419.field_15248, 1, 1, false);
			}
		}
		if (world instanceof class_3218 _level)
			_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
					"playsound enchancement:entity.generic.impact player @p ~ ~ ~ 1 1");
		HammerEnchantsProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("sourceentity", sourceentity).build());
	}
}
