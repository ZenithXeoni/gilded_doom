package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModSounds;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.init.GildedDoomModEnchantments;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.stream.Collectors;
import java.util.Map;
import java.util.List;
import java.util.Comparator;

public class AncientHammerRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure AncientHammerRightclicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure AncientHammerRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure AncientHammerRightclicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure AncientHammerRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure AncientHammerRightclicked!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure AncientHammerRightclicked!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (class_1890.method_8225(GildedDoomModEnchantments.TORRENT, itemstack) != 0) {
			if (entity.method_24828()) {
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), GildedDoomModSounds.ENCHANTMENT_TORRENT, class_3419.field_15248, 1, 1);
					} else {
						_level.method_8486(x, y, z, GildedDoomModSounds.ENCHANTMENT_TORRENT, class_3419.field_15248, 1, 1, false);
					}
				}
				{
					final class_243 _center = new class_243(x, y, z);
					List<class_1297> _entfound = world.method_8390(class_1297.class, new class_238(_center, _center).method_1014(7 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.method_5707(_center)))
							.collect(Collectors.toList());
					for (class_1297 entityiterator : _entfound) {
						if (entityiterator == entity) {
							entityiterator.method_18799(new class_243(0, 2, 0));
						} else {
							if (entity instanceof class_1657) {
								if (entityiterator instanceof class_1309 _entity && !_entity.field_6002.method_8608())
									_entity.method_6092(new class_1293(class_1294.field_5902, 10, 4));
							}
							entityiterator.method_18799(new class_243(0, 1, 0));
						}
					}
				}
				if (!entity.method_5715()) {
					{
						final class_243 _center = new class_243(x, y, z);
						List<class_1297> _entfound = world.method_8390(class_1297.class, new class_238(_center, _center).method_1014(7 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.method_5707(_center)))
								.collect(Collectors.toList());
						for (class_1297 entityiterator : _entfound) {
							if (entityiterator == entity) {
								entityiterator.method_5643(class_1282.field_5846, 2);
							} else {
								entityiterator.method_5643(class_1282.field_5846, 4);
							}
						}
					}
				}
				if (entity instanceof class_1657 _player)
					_player.method_7357().method_7906(itemstack.method_7909(), 100);
			} else {
				entity.method_18799(new class_243(0, (-20), 0));
				if (world instanceof class_3218 _level)
					_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
							"playsound enchancement:entity.generic.impact player @p ~ ~ ~ 1 1");
			}
		}
	}
}
