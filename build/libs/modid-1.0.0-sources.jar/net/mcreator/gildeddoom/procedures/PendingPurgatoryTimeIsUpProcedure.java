package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3218;
import java.util.Map;

public class PendingPurgatoryTimeIsUpProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure PendingPurgatoryTimeIsUp!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure PendingPurgatoryTimeIsUp!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure PendingPurgatoryTimeIsUp!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure PendingPurgatoryTimeIsUp!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure PendingPurgatoryTimeIsUp!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingpurgatory", entity) == 1) {
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("pendingpurgatory");
				if (_so == null)
					_so = _sc.method_1168("pendingpurgatory", class_274.field_1468, class_2561.method_43470("pendingpurgatory"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("purgatory");
				if (_so == null)
					_so = _sc.method_1168("purgatory", class_274.field_1468, class_2561.method_43470("purgatory"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
			}
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:block.respawn_anchor.ambient master @a ~ ~ ~ 1 0.5");
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:block.respawn_anchor.deplete master @a ~ ~ ~ 1 0.5");
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 0.73");
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5");
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			PurgatoryAmalgamRightclickedProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
			if (world instanceof class_1937 _level && !_level.method_8608())
				_level.method_8437(null, x, y, z, 10, class_1927.class_4179.field_18687);
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"tellraw @a {\"text\":\"No mortal shall escape the Gilded Embrace of Doom.\",\"italic\":true,\"color\":\"dark_red\"}");
		}
	}
}
