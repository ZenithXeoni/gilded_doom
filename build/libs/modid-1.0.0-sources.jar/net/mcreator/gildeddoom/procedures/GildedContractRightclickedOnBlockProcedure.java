package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModSounds;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.Map;

public class GildedContractRightclickedOnBlockProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure GildedContractRightclickedOnBlock!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure GildedContractRightclickedOnBlock!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure GildedContractRightclickedOnBlock!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure GildedContractRightclickedOnBlock!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure GildedContractRightclickedOnBlock!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure GildedContractRightclickedOnBlock!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (!itemstack.method_7948().method_10577("SoulPresent") && (entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.GILDED_EMPOWERMENT) : false) && entity.method_5715()) {
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 60);
			if ((itemstack.method_7948().method_10558("MessageSoul")).equals(entity.method_5476().getString()) && itemstack.method_7948().method_10577("UPMessageGiven")) {
				itemstack.method_7948().method_10582("PlayerSoul", entity.method_5820());
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_17481, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_17481, class_3419.field_15254, 1, 1, false);
					}
				}
				if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) > 2) {
					if (world instanceof class_1937 _level) {
						if (!_level.method_8608()) {
							_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15119, class_3419.field_15254, 1, 1);
						} else {
							_level.method_8486(x, y, z, class_3417.field_15119, class_3419.field_15254, 1, 1, false);
						}
					}
					itemstack.method_7948().method_10556("SoulPresent", true);
					itemstack.method_7948().method_10556("BanBlocked", true);
					itemstack.method_7948().method_10556("KillBlocked", true);
					itemstack.method_7948().method_10556("ReturnBlocked", true);
					itemstack.method_7948().method_10556("CustomSoul", true);
					if (world instanceof class_1937 _level) {
						if (!_level.method_8608()) {
							_level.method_8396(null, new class_2338(x, y, z), GildedDoomModSounds.ULTIMATE_POWER_CHARGE_UP, class_3419.field_15254, 1, 1);
						} else {
							_level.method_8486(x, y, z, GildedDoomModSounds.ULTIMATE_POWER_CHARGE_UP, class_3419.field_15254, 1, 1, false);
						}
					}
					{
						class_1297 _ent = entity;
						if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
							_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
									_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle endermanoverhaul:soul_fire ~ ~1.5 ~ 0 0 0 1 100 normal");
						}
					}
					{
						class_1297 _ent = entity;
						if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
							_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
									_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle minecraft:enchant ~ ~2.5 ~ 1 1 1 3 100 force");
						}
					}
					{
						class_1297 _ent = entity;
						if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
							_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
									_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle minecraft:block gilded_blackstone ~ ~2 ~ .5 .5 .5 2 100 normal");
						}
					}
					if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_STASIS, 60, 0));
					new Object() {
						private int ticks = 0;

						public void startDelay(class_1936 world) {
							ServerTickEvents.END_SERVER_TICK.register((server) -> {
								this.ticks++;
								if (this.ticks == 60) {
									{
										class_1297 _ent = entity;
										if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
											_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(),
													_ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4, _ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent),
													"playsound minecraft:block.end_portal.spawn player @a");
										}
									}
									{
										class_1297 _ent = entity;
										if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
											_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(),
													_ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4, _ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent),
													"particle minecraft:soul_fire_flame ~ ~1.5 ~ 0 0 0 0.5 100 force");
										}
									}
									{
										class_1297 _ent = entity;
										if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
											_ent.method_5682().method_3734()
													.method_44252(
															new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4, _ent.method_5477().getString(),
																	_ent.method_5476(), _ent.field_6002.method_8503(), _ent),
															("set_max_health " + entity.method_5820() + " " + ((entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) - 2)));
										}
									}
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("user_has_ultimate_power");
										if (_so == null)
											_so = _sc.method_1168("user_has_ultimate_power", class_274.field_1468, class_2561.method_43470("user_has_ultimate_power"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
									}
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("ObjectiveComplete");
										if (_so == null)
											_so = _sc.method_1168("ObjectiveComplete", class_274.field_1468, class_2561.method_43470("ObjectiveComplete"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
									}
									if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
										_entity.method_6092(new class_1293(GildedDoomModMobEffects.ULTIMATE_POWER, 60, 0));
									if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
										_player.method_7353(class_2561.method_43470("\u00A76\u00A7oHow to use Gilded Banishment"), false);
									if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
										_player.method_7353(class_2561.method_43470("\u00A76\u00A7o--"), false);
									if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
										_player.method_7353(class_2561.method_43470(
												"\u00A76\u00A7oYou must first have a Gilded Banisher. Once you have that item, hitting someone has a 25% chance to inflict Death\u2019s Mark. When someone is under Death\u2019s Mark, and they get hit with your gilded banisher at Half Health, they receive Pending Death. "),
												false);
									if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
										_player.method_7353(class_2561.method_43470("\u00A76\u00A7o--"), false);
									if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
										_player.method_7353(class_2561.method_43470(
												"\u00A76\u00A7oOnce Pending Death is applied, your objective will be marked as complete. Pending Death will either go off after time, or go off as soon as they get killed, so watch out for the bomb that comes after you kill them."),
												false);
									return;
								}
							});
						}
					}.startDelay(world);
				} else {
					if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
						_player.method_7353(class_2561.method_43470("You do not have the health for this."), false);
				}
			} else {
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("\u00A76\u00A7oThose who seek ultimate power shall let a part of their life be taken from this book(1 Heart)."), false);
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("\u00A76\u00A7o--"), false);
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470(
							"\u00A76\u00A7oUpon signature, you will be tasked to kill someone with Pending Death without dying once after signing this contract. If you end up dying, you will have a curse inflicted upon you - increasing with each death, with a max of 3, dying on max curse results in 7 day bans."),
							false);
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("\u00A76\u00A7o--"), false);
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470(
							"\u00A76\u00A7oAfter you complete your objective, this contract shall remain active. You will remain capable of wielding your unlocked power. If your Greed remains Unsatiated, come back to me for even more power."),
							false);
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("\u00A77\u00A7o--A copy your Soul will be engraved, but it not be able to kill, ban, or return"), false);
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("\u00A7cCrouch Interact to sign."), false);
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_17481, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_17481, class_3419.field_15254, 1, 1, false);
					}
				}
				itemstack.method_7948().method_10556("UPMessageGiven", true);
				itemstack.method_7948().method_10582("MessageSoul", (entity.method_5476().getString()));
			}
		} else if (!itemstack.method_7948().method_10577("SoulPresent")) {
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 100);
			if ((itemstack.method_7948().method_10558("MessageSoul")).equals(entity.method_5476().getString()) && itemstack.method_7948().method_10577("MessageGiven")) {
				itemstack.method_7948().method_10582("PlayerSoul", entity.method_5820());
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_17481, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_17481, class_3419.field_15254, 1, 1, false);
					}
				}
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15119, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_15119, class_3419.field_15254, 1, 1, false);
					}
				}
				itemstack.method_7948().method_10556("SoulPresent", true);
				itemstack.method_7948().method_10556("BanBlocked", true);
				itemstack.method_7948().method_10556("ReturnBlocked", true);
				itemstack.method_7948().method_10556("CustomSoul", true);
			} else {
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("<???> By signing this contract you are aware that your soul will be controlled by this contract"), false);
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_17481, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_17481, class_3419.field_15254, 1, 1, false);
					}
				}
				itemstack.method_7948().method_10556("MessageGiven", true);
				itemstack.method_7948().method_10582("MessageSoul", (entity.method_5476().getString()));
			}
		} else if (itemstack.method_7948().method_10577("SoulPresent") && (entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.GILDED_EMPOWERMENT) : false) && entity.method_5715()) {
			if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
				_player.method_7353(class_2561.method_43470("\u00A7cYou must use an Empty Contract"), false);
		} else {
			if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
				_player.method_7353(class_2561.method_43470(("Contracted Soul: " + itemstack.method_7948().method_10558("PlayerSoul"))), true);
		}
	}
}
