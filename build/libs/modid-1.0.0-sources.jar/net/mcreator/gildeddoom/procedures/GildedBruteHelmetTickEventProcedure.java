package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import java.util.Map;

public class GildedBruteHelmetTickEventProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure GildedBruteHelmetTickEvent!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) >= (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) && entity.method_5715() && entity.method_24828()) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5905, 60, 0));
		}
	}
}
