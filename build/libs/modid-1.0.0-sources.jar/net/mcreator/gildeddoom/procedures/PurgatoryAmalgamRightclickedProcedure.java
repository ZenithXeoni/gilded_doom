package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_3218;
import java.util.Map;

public class PurgatoryAmalgamRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure PurgatoryAmalgamRightclicked!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (true) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run fill -5 69 -5 5 69 5 gilded_doom:purgatory_nylium");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run fill -5 70 -5 5 75 5 air");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run setblock 1 70 0 minecraft:crafting_table");
				}
			}
		}
		{
			class_1297 _ent = entity;
			if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
				_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
						_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run tp @s 0 70 0");
			}
		}
		{
			class_1297 _ent = entity;
			if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
				_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
						_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run spawnpoint @s 0 70 0");
			}
		}
		if (true) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run fill -5 69 -5 5 69 5 gilded_doom:purgatory_nylium");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run fill -5 70 -5 5 75 5 air");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in gilded_doom:purgatory_dimension run setblock 1 70 0 minecraft:crafting_table");
				}
			}
		}
	}
}
