package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_243;
import java.util.Map;

public class GildedStasisOnEffectActiveTickProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure GildedStasisOnEffectActiveTick!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		entity.method_18799(new class_243(0, (-10), 0));
		entity.method_5844(class_2246.field_10124.method_9564(), new class_243(0.25, 0.05, 0.25));
	}
}
