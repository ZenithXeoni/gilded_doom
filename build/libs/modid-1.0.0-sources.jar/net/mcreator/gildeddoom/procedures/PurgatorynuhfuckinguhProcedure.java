package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import java.util.Map;
import java.util.HashMap;

public class PurgatorynuhfuckinguhProcedure {
	public PurgatorynuhfuckinguhProcedure() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", handler.method_32311());
			dependencies.put("x", handler.method_32311().method_23317());
			dependencies.put("y", handler.method_32311().method_23318());
			dependencies.put("z", handler.method_32311().method_23321());
			dependencies.put("world", handler.method_32311().method_14220());
			execute(dependencies);
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure Purgatorynuhfuckinguh!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		if ((entity.field_6002.method_27983()) == (class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))) {
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("purgatory");
				if (_so == null)
					_so = _sc.method_1168("purgatory", class_274.field_1468, class_2561.method_43470("purgatory"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
			}
		}
	}
}
