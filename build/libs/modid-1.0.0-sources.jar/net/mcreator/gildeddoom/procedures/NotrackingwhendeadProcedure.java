package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;

import java.util.Map;
import java.util.HashMap;

public class NotrackingwhendeadProcedure {
	public NotrackingwhendeadProcedure() {
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", newPlayer.method_23317());
			dependencies.put("y", newPlayer.method_23318());
			dependencies.put("z", newPlayer.method_23321());
			dependencies.put("world", newPlayer.field_6002);
			dependencies.put("entity", newPlayer);
			dependencies.put("oldEntity", oldPlayer);
			execute(dependencies);
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure Notrackingwhendead!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (entity instanceof class_1657 _player)
			_player.method_7357().method_7906(GildedDoomModItems.TRACKING_TOME, 12000);
	}
}
