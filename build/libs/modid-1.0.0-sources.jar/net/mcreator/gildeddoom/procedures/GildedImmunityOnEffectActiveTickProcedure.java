package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class GildedImmunityOnEffectActiveTickProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure GildedImmunityOnEffectActiveTick!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (entity instanceof class_1309 _entity)
			_entity.method_6016(GildedDoomModMobEffects.DEATHS_MARK);
		if (entity instanceof class_1309 _entity)
			_entity.method_6016(GildedDoomModMobEffects.GILDED_STASIS);
	}
}
