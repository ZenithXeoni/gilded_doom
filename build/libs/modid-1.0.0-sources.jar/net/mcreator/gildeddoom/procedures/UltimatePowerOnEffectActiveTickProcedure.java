package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1936;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.mcreator.gildeddoom.init.GildedDoomModGameRules;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;

import java.util.Map;
import java.util.HashMap;

public class UltimatePowerOnEffectActiveTickProcedure {
	public UltimatePowerOnEffectActiveTickProcedure() {
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", newPlayer.method_23317());
			dependencies.put("y", newPlayer.method_23318());
			dependencies.put("z", newPlayer.method_23321());
			dependencies.put("world", newPlayer.field_6002);
			dependencies.put("entity", newPlayer);
			dependencies.put("oldEntity", oldPlayer);
			execute(dependencies);
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure UltimatePowerOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure UltimatePowerOnEffectActiveTick!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (world.method_8401().method_146().method_8355(GildedDoomModGameRules.ALLOWGILDEDBANISHMENT) && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("user_has_ultimate_power", entity) == 1) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(GildedDoomModMobEffects.ULTIMATE_POWER, 200, 0));
		}
		if (world.method_8401().method_146().method_8355(GildedDoomModGameRules.ALLOWGILDEDBANISHMENT) && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("user_has_ultimate_power", entity) == 2) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(GildedDoomModMobEffects.ULTIMATE_POWER, 200, 1));
		}
	}
}
