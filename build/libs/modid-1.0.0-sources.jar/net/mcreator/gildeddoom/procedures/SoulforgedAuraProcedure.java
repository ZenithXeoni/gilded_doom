package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1936;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import java.util.Map;

public class SoulforgedAuraProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure SoulforgedAura!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure SoulforgedAura!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure SoulforgedAura!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure SoulforgedAura!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		if (world instanceof class_3218 _level)
			_level.method_14199(class_2398.field_22246, x, y, z, 1, 5, 5, 5, 0);
	}
}
