package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class FreeMeRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure FreeMeRightclicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure FreeMeRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure FreeMeRightclicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure FreeMeRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure FreeMeRightclicked!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure FreeMeRightclicked!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (world.method_8608())
			class_310.method_1551().field_1773.method_3189(new class_1799(GildedDoomModItems.FREE_ME));
		if (world instanceof class_1937 _level) {
			if (!_level.method_8608()) {
				_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14931, class_3419.field_15254, 1, 1);
			} else {
				_level.method_8486(x, y, z, class_3417.field_14931, class_3419.field_15254, 1, 1, false);
			}
		}
		{
			class_1297 _ent = entity;
			class_269 _sc = _ent.method_37908().method_8428();
			class_266 _so = _sc.method_1170("DuckSouls");
			if (_so == null)
				_so = _sc.method_1168("DuckSouls", class_274.field_1468, class_2561.method_43470("DuckSouls"), class_274.class_275.field_1472);
			_sc.method_1180(_ent.method_5820(), _so).method_1128(500);
		}
		{
			class_1297 _ent = entity;
			class_269 _sc = _ent.method_37908().method_8428();
			class_266 _so = _sc.method_1170("WitherSouls");
			if (_so == null)
				_so = _sc.method_1168("WitherSouls", class_274.field_1468, class_2561.method_43470("WitherSouls"), class_274.class_275.field_1472);
			_sc.method_1180(_ent.method_5820(), _so).method_1128(200);
		}
		{
			class_1297 _ent = entity;
			class_269 _sc = _ent.method_37908().method_8428();
			class_266 _so = _sc.method_1170("PiglinBruteSouls");
			if (_so == null)
				_so = _sc.method_1168("PiglinBruteSouls", class_274.field_1468, class_2561.method_43470("PiglinBruteSouls"), class_274.class_275.field_1472);
			_sc.method_1180(_ent.method_5820(), _so).method_1128(10);
		}
		(itemstack).method_7934(1);
	}
}
