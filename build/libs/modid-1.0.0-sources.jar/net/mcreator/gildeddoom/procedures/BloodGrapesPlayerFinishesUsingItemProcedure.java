package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import java.util.Map;

public class BloodGrapesPlayerFinishesUsingItemProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure BloodGrapesPlayerFinishesUsingItem!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure BloodGrapesPlayerFinishesUsingItem!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure BloodGrapesPlayerFinishesUsingItem!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure BloodGrapesPlayerFinishesUsingItem!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure BloodGrapesPlayerFinishesUsingItem!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (class_3532.method_15395(class_5819.method_43047(), 1, 200) == 0 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("deathcurse", entity) > 0) {
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_21949, class_3419.field_15254, 1, 1);
				} else {
					_level.method_8486(x, y, z, class_3417.field_21949, class_3419.field_15254, 1, 1, false);
				}
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("deathcurse");
				if (_so == null)
					_so = _sc.method_1168("deathcurse", class_274.field_1468, class_2561.method_43470("deathcurse"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("deathcurse", entity) - 1));
			}
		}
	}
}
