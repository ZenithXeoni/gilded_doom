package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModSounds;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.mcreator.gildeddoom.init.GildedDoomModEnchantments;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import java.util.Map;
import java.util.HashMap;

public class HammerEnchantsProcedure {
	public HammerEnchantsProcedure() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, damageSource, amount) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", entity);
			dependencies.put("x", entity.method_23317());
			dependencies.put("y", entity.method_23318());
			dependencies.put("z", entity.method_23321());
			dependencies.put("world", entity.field_6002);
			dependencies.put("sourceentity", damageSource.method_5529());
			dependencies.put("immediatesourceentity", damageSource.method_5526());
			dependencies.put("amount", amount);
			execute(dependencies);
			return true;
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure HammerEnchants!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure HammerEnchants!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure HammerEnchants!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure HammerEnchants!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure HammerEnchants!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure HammerEnchants!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if (class_1890.method_8225(GildedDoomModEnchantments.TORRENT, (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037)) != 0
				&& !((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.ANCIENT_HAMMER)) {
			if (sourceentity.method_5715() && (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.GILDED_BANISHER) {
				entity.method_18799(new class_243(0, (-20), 0));
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), GildedDoomModSounds.ANCIENT_HAMMER_SLAM, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, GildedDoomModSounds.ANCIENT_HAMMER_SLAM, class_3419.field_15254, 1, 1, false);
					}
				}
			} else if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER) {
				entity.method_18799(new class_243(0, 1, 0));
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), GildedDoomModSounds.ENCHANTMENT_TORRENT, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, GildedDoomModSounds.ENCHANTMENT_TORRENT, class_3419.field_15254, 1, 1, false);
					}
				}
				if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) >= 0.5) {
					if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5902, 30, 0));
				} else if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) >= 0.25) {
					if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5902, 20, 0));
				} else {
					if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5902, 10, 0));
				}
			} else {
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5902, 10, 1));
				entity.method_18799(new class_243(0, 1, 0));
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), GildedDoomModSounds.ENCHANTMENT_TORRENT, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, GildedDoomModSounds.ENCHANTMENT_TORRENT, class_3419.field_15254, 1, 1, false);
					}
				}
			}
		}
		if (class_1890.method_8225(GildedDoomModEnchantments.KNOCKOUT, (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037)) != 0 && class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1
				&& !(entity instanceof class_1309 _livEnt ? _livEnt.method_6039() : false)) {
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14833, class_3419.field_15248, 1, (float) 0.75);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14833, class_3419.field_15248, 1, (float) 0.75, false);
				}
			}
			if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) >= 0.5) {
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5919, (int) ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER ? 150 : 100), 0));
			} else if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) >= 0.25) {
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5919, (int) ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER ? 80 : 120), 0));
			} else {
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5919, (int) ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER ? 40 : 60), 0));
			}
		}
		if (class_1890.method_8225(GildedDoomModEnchantments.FORTITUDE, (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037)) != 0) {
			if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) <= 0.25) {
				if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.HELLFORGED_HAMMER) {
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5910, 100, 1));
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5901, 100, 1));
				} else if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER) {
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5907, 100, 1));
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5911, 100, 1));
				} else {
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5907, 100, 1));
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5909, 100, 1));
				}
			} else if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) <= 0.5) {
				if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.HELLFORGED_HAMMER) {
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5910, 100, 0));
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5901, 100, 0));
				} else if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER) {
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5907, 100, 0));
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5911, 100, 0));
				} else {
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5907, 100, 0));
					if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5909, 100, 0));
				}
			}
		}
	}
}
