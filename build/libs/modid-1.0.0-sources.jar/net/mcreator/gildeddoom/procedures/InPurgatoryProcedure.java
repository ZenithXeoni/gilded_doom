package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_161;
import net.minecraft.class_1657;
import net.minecraft.class_167;
import net.minecraft.class_1799;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;
import java.util.Iterator;

public class InPurgatoryProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure InPurgatory!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure InPurgatory!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (entity instanceof class_1657 _player)
			_player.method_7357().method_7906(itemstack.method_7909(), 100);
		if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
			_player.method_7353(class_2561.method_43470("Soul Requirements:"), false);
		if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
			_player.method_7353(class_2561.method_43470("----------------------"), false);
		if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
			_player.method_7353(class_2561.method_43470(("Blazes: " + (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("BlazeSouls", entity)) + "/200")), false);
		if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
			_player.method_7353(class_2561.method_43470(("Skeletons: " + (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("SkeletonSouls", entity)) + "/200")), false);
		if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
			_player.method_7353(class_2561.method_43470(("Piglins: " + (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("PiglinSouls", entity)) + "/200")), false);
		if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
			_player.method_7353(class_2561.method_43470("----------------------"), false);
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("purgatory", entity) == 2) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in minecraft:overworld run tp @s 0 100 0");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in minecraft:overworld run spawnpoint @s 0 100 0");
				}
			}
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_STASIS, 200, 0));
			if (entity instanceof class_3222 _player) {
				class_161 _adv = _player.field_13995.method_3851().method_12896(new class_2960("gilded_doom:freeatlast"));
				class_167 _ap = _player.method_14236().method_12882(_adv);
				if (!_ap.method_740()) {
					Iterator _iterator = _ap.method_731().iterator();
					while (_iterator.hasNext())
						_player.method_14236().method_12878(_adv, (String) _iterator.next());
				}
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("BlazeSouls");
				if (_so == null)
					_so = _sc.method_1168("BlazeSouls", class_274.field_1468, class_2561.method_43470("BlazeSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("SkeletonSouls");
				if (_so == null)
					_so = _sc.method_1168("SkeletonSouls", class_274.field_1468, class_2561.method_43470("SkeletonSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("PiglinSouls");
				if (_so == null)
					_so = _sc.method_1168("PiglinSouls", class_274.field_1468, class_2561.method_43470("PiglinSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
		}
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("BlazeSouls", entity) >= 200 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("SkeletonSouls", entity) >= 200 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("PiglinSouls", entity) >= 200) {
			if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
				_player.method_7353(class_2561.method_43470("Your task is complete; Purgatory unbinds you, you are free to escape. right-clicking this again will send you back to the overworld at 0 100 0"), false);
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("purgatory");
				if (_so == null)
					_so = _sc.method_1168("purgatory", class_274.field_1468, class_2561.method_43470("purgatory"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(2);
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("purgatorytracker");
				if (_so == null)
					_so = _sc.method_1168("purgatorytracker", class_274.field_1468, class_2561.method_43470("purgatorytracker"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("purgatorytracker", entity) + 1));
			}
			if (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("purgatorytracker", entity) >= 2) {
				if (entity instanceof class_3222 _player) {
					class_161 _adv = _player.field_13995.method_3851().method_12896(new class_2960("gilded_doom:purgatory_complete"));
					class_167 _ap = _player.method_14236().method_12882(_adv);
					if (!_ap.method_740()) {
						Iterator _iterator = _ap.method_731().iterator();
						while (_iterator.hasNext())
							_player.method_14236().method_12878(_adv, (String) _iterator.next());
					}
				}
			}
		}
	}
}
