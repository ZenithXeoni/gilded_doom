package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1936;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3218;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;

import java.util.Map;
import java.util.HashMap;

public class ObjectivePunishmentProcedure {
	public ObjectivePunishmentProcedure() {
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", newPlayer.method_23317());
			dependencies.put("y", newPlayer.method_23318());
			dependencies.put("z", newPlayer.method_23321());
			dependencies.put("world", newPlayer.field_6002);
			dependencies.put("entity", newPlayer);
			dependencies.put("oldEntity", oldPlayer);
			execute(dependencies);
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure ObjectivePunishment!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure ObjectivePunishment!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure ObjectivePunishment!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure ObjectivePunishment!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure ObjectivePunishment!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("ObjectiveComplete", entity) == 0 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("user_has_ultimate_power", entity) > 0) {
			if (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("user_has_ultimate_power", entity) == 1) {
				if (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("deathcurse", entity) == 3) {
					if (world instanceof class_3218 _level)
						_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
								("tempban " + entity.method_5476().getString() + " 7d Contract Penalty"));
				} else if (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("deathcurse", entity) > 0) {
					{
						class_1297 _ent = entity;
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170("deathcurse");
						if (_so == null)
							_so = _sc.method_1168("deathcurse", class_274.field_1468, class_2561.method_43470("deathcurse"), class_274.class_275.field_1472);
						_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
							public int getScore(String score, class_1297 _ent) {
								class_269 _sc = _ent.method_37908().method_8428();
								class_266 _so = _sc.method_1170(score);
								if (_so != null)
									return _sc.method_1180(_ent.method_5820(), _so).method_1126();
								return 0;
							}
						}.getScore("deathcurse", entity) + 1));
					}
				} else {
					{
						class_1297 _ent = entity;
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170("deathcurse");
						if (_so == null)
							_so = _sc.method_1168("deathcurse", class_274.field_1468, class_2561.method_43470("deathcurse"), class_274.class_275.field_1472);
						_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
					}
				}
			} else {
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("You have reached In development content, Good Job :3"), false);
			}
		}
	}
}
