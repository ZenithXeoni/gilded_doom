package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import java.util.Map;
import java.util.HashMap;

public class TomehittingProcedure {
	public TomehittingProcedure() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, damageSource, amount) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", entity);
			dependencies.put("x", entity.method_23317());
			dependencies.put("y", entity.method_23318());
			dependencies.put("z", entity.method_23321());
			dependencies.put("world", entity.field_6002);
			dependencies.put("sourceentity", damageSource.method_5529());
			dependencies.put("amount", amount);
			execute(dependencies);
			return true;
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure Tomehitting!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure Tomehitting!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7909() == GildedDoomModItems.BRUTAL_TOME
				&& ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == class_1802.field_8825
						|| (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.GILDED_BANISHER)) {
			if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) >= 0.5) {
				if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5907, 100, 0));
			}
			if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) <= 0.5) {
				if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5917, 100, 0));
			}
		}
		if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7909() == GildedDoomModItems.WITHERING_TOME
				&& ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.SOULFORGED_HAMMER
						|| (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == class_1802.field_8528)) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5920, 200, 1));
			if (sourceentity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5920, 100, 1));
		}
	}
}
