package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1528;
import net.minecraft.class_1639;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5419;
import net.mcreator.gildeddoom.entity.DuckEntity;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import java.util.Map;
import java.util.HashMap;

public class DuckspawninpurgatoryProcedure {
	public DuckspawninpurgatoryProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", entity);
			dependencies.put("x", entity.method_23317());
			dependencies.put("y", entity.method_23318());
			dependencies.put("z", entity.method_23321());
			dependencies.put("world", entity.field_6002);
			dependencies.put("sourceentity", damageSource.method_5529());
			execute(dependencies);
			return true;
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure Duckspawninpurgatory!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure Duckspawninpurgatory!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if (entity instanceof class_1639 && (entity.field_6002.method_27983()) == (class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))
				&& (sourceentity instanceof class_1657 _playerHasItem ? _playerHasItem.method_31548().method_7379(new class_1799(GildedDoomModItems.PURGATORY_AMALGAM)) : false)) {
			{
				class_1297 _ent = sourceentity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("WitherSouls");
				if (_so == null)
					_so = _sc.method_1168("WitherSouls", class_274.field_1468, class_2561.method_43470("WitherSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("WitherSouls", sourceentity) + 1));
			}
		}
		if (entity instanceof class_1528 && (entity.field_6002.method_27983()) == (class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))
				&& (sourceentity instanceof class_1657 _playerHasItem ? _playerHasItem.method_31548().method_7379(new class_1799(GildedDoomModItems.PURGATORY_AMALGAM)) : false)) {
			{
				class_1297 _ent = sourceentity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("WitherSouls");
				if (_so == null)
					_so = _sc.method_1168("WitherSouls", class_274.field_1468, class_2561.method_43470("WitherSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("WitherSouls", sourceentity) + 10));
			}
		}
		if (entity instanceof DuckEntity && (entity.field_6002.method_27983()) == (class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))
				&& (sourceentity instanceof class_1657 _playerHasItem ? _playerHasItem.method_31548().method_7379(new class_1799(GildedDoomModItems.PURGATORY_AMALGAM)) : false)) {
			{
				class_1297 _ent = sourceentity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("DuckSouls");
				if (_so == null)
					_so = _sc.method_1168("DuckSouls", class_274.field_1468, class_2561.method_43470("DuckSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("DuckSouls", sourceentity) + 1));
			}
		}
		if (entity instanceof class_5419 && (entity.field_6002.method_27983()) == (class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))
				&& (sourceentity instanceof class_1657 _playerHasItem ? _playerHasItem.method_31548().method_7379(new class_1799(GildedDoomModItems.PURGATORY_AMALGAM)) : false)) {
			{
				class_1297 _ent = sourceentity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("PiglinBruteSouls");
				if (_so == null)
					_so = _sc.method_1168("PiglinBruteSouls", class_274.field_1468, class_2561.method_43470("PiglinBruteSouls"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
					public int getScore(String score, class_1297 _ent) {
						class_269 _sc = _ent.method_37908().method_8428();
						class_266 _so = _sc.method_1170(score);
						if (_so != null)
							return _sc.method_1180(_ent.method_5820(), _so).method_1126();
						return 0;
					}
				}.getScore("PiglinBruteSouls", sourceentity) + 1));
			}
		}
	}
}
