package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class DuckRightClickedOnEntityProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure DuckRightClickedOnEntity!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure DuckRightClickedOnEntity!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (itemstack.method_7909() == GildedDoomModItems.BLOOD_GRAPES) {
			(itemstack).method_7934(1);
			if (!entity.field_6002.method_8608())
				entity.method_31472();
		}
	}
}
