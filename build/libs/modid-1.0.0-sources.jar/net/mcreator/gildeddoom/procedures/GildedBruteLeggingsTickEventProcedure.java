package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_161;
import net.minecraft.class_167;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;
import java.util.Iterator;

public class GildedBruteLeggingsTickEventProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure GildedBruteLeggingsTickEvent!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_7909() == GildedDoomModItems.GILDED_BRUTE_HELMET
				&& (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_7909() == GildedDoomModItems.GILDED_BRUTE_CHESTPLATE
				&& (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_7909() == GildedDoomModItems.GILDED_BRUTE_LEGGINGS
				&& (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7909() == GildedDoomModItems.GILDED_BRUTE_BOOTS) {
			if (entity instanceof class_3222 _player) {
				class_161 _adv = _player.field_13995.method_3851().method_12896(new class_2960("gilded_doom:cover_me_in_riches"));
				class_167 _ap = _player.method_14236().method_12882(_adv);
				if (!_ap.method_740()) {
					Iterator _iterator = _ap.method_731().iterator();
					while (_iterator.hasNext())
						_player.method_14236().method_12878(_adv, (String) _iterator.next());
				}
			}
			if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) > 0.75) {
				if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6059(class_1294.field_5907) : false)
						&& (entity instanceof class_1309 _livEnt && _livEnt.method_6059(class_1294.field_5907) ? _livEnt.method_6112(class_1294.field_5907).method_5578() : 0) == 0) {
					if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5907,
								(int) ((entity instanceof class_1309 _livEnt && _livEnt.method_6059(class_1294.field_5907) ? _livEnt.method_6112(class_1294.field_5907).method_5584() : 0) * 0.75), 1));
				}
			} else if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) / (entity instanceof class_1309 _livEnt ? _livEnt.method_6063() : -1) <= 0.25) {
				if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6059(class_1294.field_5917) : false)
						&& (entity instanceof class_1309 _livEnt && _livEnt.method_6059(class_1294.field_5917) ? _livEnt.method_6112(class_1294.field_5917).method_5578() : 0) == 0) {
					if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5917, (int) ((entity instanceof class_1309 _livEnt && _livEnt.method_6059(class_1294.field_5917) ? _livEnt.method_6112(class_1294.field_5917).method_5584() : 0) * 0.75), 1));
				}
			}
		}
	}
}
