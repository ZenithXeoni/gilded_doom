package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModGameRules;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class BrutalTomeRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure BrutalTomeRightclicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure BrutalTomeRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure BrutalTomeRightclicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure BrutalTomeRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure BrutalTomeRightclicked!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure BrutalTomeRightclicked!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (!world.method_8401().method_146().method_8355(GildedDoomModGameRules.BOOK_UNLOCKED) && world.method_8401().method_146().method_8355(GildedDoomModGameRules.ALLOWGILDEDBANISHMENT) && entity.method_5715()) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(
							new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4, _ent.method_5477().getString(), _ent.method_5476(),
									_ent.field_6002.method_8503(), _ent),
							"tellraw @a [\"\",{\"text\":\"You sense a demonic presence rise from an unknown place to The Mortal Realm. \u2014 one has summoned the Deal, but cannot claim it. ..-. --- .-. / -. --- .--\",\"italic\":true,\"color\":\"gold\",\"bold\":true}]");
				}
			}
			(itemstack).method_7934(1);
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "give @s gilded_doom:book_of_gilded_banishment");
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_24065, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_24065, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_24063, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_24063, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_24061, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_24061, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_24062, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_24062, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14891, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14891, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14792, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14792, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15045, class_3419.field_15250, 100, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_15045, class_3419.field_15250, 100, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level)
				_level.method_8450().method_20746(GildedDoomModGameRules.BOOK_UNLOCKED).method_20758(true, _level.method_8503());
		}
	}
}
