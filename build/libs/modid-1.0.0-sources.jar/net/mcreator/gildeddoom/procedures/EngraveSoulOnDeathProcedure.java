package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import java.util.Map;
import java.util.HashMap;

public class EngraveSoulOnDeathProcedure {
	public EngraveSoulOnDeathProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", entity);
			dependencies.put("x", entity.method_23317());
			dependencies.put("y", entity.method_23318());
			dependencies.put("z", entity.method_23321());
			dependencies.put("world", entity.field_6002);
			dependencies.put("sourceentity", damageSource.method_5529());
			execute(dependencies);
			return true;
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure EngraveSoulOnDeath!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure EngraveSoulOnDeath!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure EngraveSoulOnDeath!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure EngraveSoulOnDeath!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure EngraveSoulOnDeath!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure EngraveSoulOnDeath!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7909() == GildedDoomModItems.TRACKING_TOME) {
			(sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7948().method_10556("SoulPresent", true);
			(sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7948().method_10556("ReturnBlocked", true);
			(sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7948().method_10556("SoulControl", false);
			(sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7948().method_10556("KillBlocked", true);
			(sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7948().method_10556("BanBlocked", true);
			(sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7948().method_10582("PlayerSoul", entity.method_5820());
			entity.method_5728(false);
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15119, class_3419.field_15254, 1, 1);
				} else {
					_level.method_8486(x, y, z, class_3417.field_15119, class_3419.field_15254, 1, 1, false);
				}
			}
		}
	}
}
