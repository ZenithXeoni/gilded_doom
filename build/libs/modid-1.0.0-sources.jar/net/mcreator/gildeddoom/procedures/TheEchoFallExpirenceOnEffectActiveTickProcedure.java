package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import java.util.Map;

public class TheEchoFallExpirenceOnEffectActiveTickProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure TheEchoFallExpirenceOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure TheEchoFallExpirenceOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure TheEchoFallExpirenceOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure TheEchoFallExpirenceOnEffectActiveTick!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double repeatwait = 0;
		if (1 == class_3532.method_15395(class_5819.method_43047(), 1, 20)) {
			sx = x;
			sy = y;
			sz = z;
			{
				class_1297 _ent = entity;
				_ent.method_5859(sx, sy, sz);
				if (_ent instanceof class_3222 _serverPlayer)
					_serverPlayer.field_13987.method_14363(sx, sy, sz, _ent.method_36454(), _ent.method_36455());
			}
			entity.method_18799(new class_243(0, 0, 0));
		}
		if (1 == class_3532.method_15395(class_5819.method_43047(), 1, 6000)) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "kick @s timed out, lmao");
				}
			}
		}
	}
}
