package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import java.util.Map;
import java.util.HashMap;

public class ThornsProcedure {
	public ThornsProcedure() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, damageSource, amount) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", entity);
			dependencies.put("x", entity.method_23317());
			dependencies.put("y", entity.method_23318());
			dependencies.put("z", entity.method_23321());
			dependencies.put("world", entity.field_6002);
			dependencies.put("sourceentity", damageSource.method_5529());
			dependencies.put("amount", amount);
			execute(dependencies);
			return true;
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure Thorns!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure Thorns!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure Thorns!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure Thorns!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure Thorns!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure Thorns!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if (GildedDoomModItems.GILDED_BRUTE_CHESTPLATE == (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_7909()) {
			if (!(class_3532.method_15395(class_5819.method_43047(), 1, 2) == 1)) {
				sourceentity.method_5643(class_1282.field_5869, (float) ((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6059(class_1294.field_5907) : false) ? 1 : class_3532.method_15395(class_5819.method_43047(), 1, 2)));
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(sourceentity.method_23317(), sourceentity.method_23318(), sourceentity.method_23321()), class_3417.field_14663, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10));
					} else {
						_level.method_8486((sourceentity.method_23317()), (sourceentity.method_23318()), (sourceentity.method_23321()), class_3417.field_14663, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10), false);
					}
				}
			}
		}
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("deathcurse", entity) == 1 && class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5911, 60, 1));
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15027, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10));
				} else {
					_level.method_8486(x, y, z, class_3417.field_15027, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10), false);
				}
			}
		} else if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("deathcurse", entity) == 2 && class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5901, 60, 0));
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5911, 60, 1));
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15027, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10));
				} else {
					_level.method_8486(x, y, z, class_3417.field_15027, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10), false);
				}
			}
		} else if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("deathcurse", entity) == 3 && class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1) {
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(GildedDoomModMobEffects.THE_ECHO_FALL_EXPERIENCE, 300, 0));
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5911, 60, 1));
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5901, 60, 0));
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15027, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10));
				} else {
					_level.method_8486(x, y, z, class_3417.field_15027, class_3419.field_15248, 1, (float) (class_3532.method_15395(class_5819.method_43047(), 8, 12) / 10), false);
				}
			}
		}
	}
}
