package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModEntities;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1936;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5819;
import net.mcreator.gildeddoom.entity.SavageDuckEntity;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class SavageDuckEntityIsHurtProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure SavageDuckEntityIsHurt!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure SavageDuckEntityIsHurt!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure SavageDuckEntityIsHurt!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure SavageDuckEntityIsHurt!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		if (class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1) {
			if (world instanceof class_3218 _level) {
				class_1297 entityToSpawn = new SavageDuckEntity(GildedDoomModEntities.SAVAGE_DUCK, _level);
				entityToSpawn.method_5808(x, y, z, 0, 0);
				entityToSpawn.method_5636(0);
				entityToSpawn.method_5847(0);
				entityToSpawn.method_18800(0, 0, 0);
				if (entityToSpawn instanceof class_1308 _mobToSpawn)
					_mobToSpawn.method_5943(_level, world.method_8404(entityToSpawn.method_24515()), class_3730.field_16471, null, null);
				world.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1297 entityToSpawn = new SavageDuckEntity(GildedDoomModEntities.SAVAGE_DUCK, _level);
				entityToSpawn.method_5808(x, y, z, 0, 0);
				entityToSpawn.method_5636(0);
				entityToSpawn.method_5847(0);
				entityToSpawn.method_18800(0, 0, 0);
				if (entityToSpawn instanceof class_1308 _mobToSpawn)
					_mobToSpawn.method_5943(_level, world.method_8404(entityToSpawn.method_24515()), class_3730.field_16471, null, null);
				world.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1297 entityToSpawn = new SavageDuckEntity(GildedDoomModEntities.SAVAGE_DUCK, _level);
				entityToSpawn.method_5808(x, y, z, 0, 0);
				entityToSpawn.method_5636(0);
				entityToSpawn.method_5847(0);
				entityToSpawn.method_18800(0, 0, 0);
				if (entityToSpawn instanceof class_1308 _mobToSpawn)
					_mobToSpawn.method_5943(_level, world.method_8404(entityToSpawn.method_24515()), class_3730.field_16471, null, null);
				world.method_8649(entityToSpawn);
			}
		}
	}
}
