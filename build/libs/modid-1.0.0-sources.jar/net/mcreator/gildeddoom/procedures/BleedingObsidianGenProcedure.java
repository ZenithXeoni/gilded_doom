package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModBlocks;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import java.util.Map;
import java.util.HashMap;

public class BleedingObsidianGenProcedure {
	public BleedingObsidianGenProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", entity);
			dependencies.put("x", entity.method_23317());
			dependencies.put("y", entity.method_23318());
			dependencies.put("z", entity.method_23321());
			dependencies.put("world", entity.field_6002);
			dependencies.put("sourceentity", damageSource.method_5529());
			execute(dependencies);
			return true;
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure BleedingObsidianGen!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure BleedingObsidianGen!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure BleedingObsidianGen!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure BleedingObsidianGen!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure BleedingObsidianGen!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (entity instanceof class_1657 && ((world.method_8320(new class_2338(x, y - 1, z))).method_26204() == class_2246.field_10540 || (world.method_8320(new class_2338(x, y - 1, z))).method_26204() == class_2246.field_22423)) {
			world.method_8652(new class_2338(x, y - 1, z), GildedDoomModBlocks.BLEEDING_OBSIDAN.method_9564(), 3);
		}
		if (entity instanceof class_1657 && (world.method_8320(new class_2338(x, y - 1, z))).method_26204() == GildedDoomModBlocks.PURGATORY_STONE) {
			world.method_8652(new class_2338(x, y - 1, z), GildedDoomModBlocks.DEMENANITE_ORE.method_9564(), 3);
		}
	}
}
