package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class GildedBanisherLivingEntityIsHitWithToolProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure GildedBanisherLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure GildedBanisherLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure GildedBanisherLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure GildedBanisherLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure GildedBanisherLivingEntityIsHitWithTool!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure GildedBanisherLivingEntityIsHitWithTool!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.DEATHS_MARK) : false) && (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.ULTIMATE_POWER) : false)
				&& (entity instanceof class_1309 _livEnt ? _livEnt.method_6032() : -1) <= 7 && !(entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.PENDING_DEATH) : false)) {
			if ((sourceentity instanceof class_1309 _livEnt && _livEnt.method_6059(GildedDoomModMobEffects.ULTIMATE_POWER) ? _livEnt.method_6112(GildedDoomModMobEffects.ULTIMATE_POWER).method_5578() : 0) == 0) {
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5911, 600, 0));
				{
					class_1297 _ent = entity;
					if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
						_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
								_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle minecraft:block gilded_blackstone ~ ~2 ~ .5 .5 .5 2 100 normal");
					}
				}
				if (world instanceof class_3218 _level)
					_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
							"tellraw @a {\"text\":\"The Gilded Execution has begun...\",\"bold\":true,\"italic\":true,\"color\":\"yellow\"}");
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14742, class_3419.field_15248, 1, (float) 0.5);
					} else {
						_level.method_8486(x, y, z, class_3417.field_14742, class_3419.field_15248, 1, (float) 0.5, false);
					}
				}
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_38060, class_3419.field_15248, 5, (float) 0.5);
					} else {
						_level.method_8486(x, y, z, class_3417.field_38060, class_3419.field_15248, 5, (float) 0.5, false);
					}
				}
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_38092, 100, 0));
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(GildedDoomModMobEffects.PENDING_DEATH, 6000, 0));
				{
					class_1297 _ent = entity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("pendingdeath");
					if (_so == null)
						_so = _sc.method_1168("pendingdeath", class_274.field_1468, class_2561.method_43470("pendingdeath"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
				}
				{
					class_1297 _ent = sourceentity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("ObjectiveComplete");
					if (_so == null)
						_so = _sc.method_1168("ObjectiveComplete", class_274.field_1468, class_2561.method_43470("ObjectiveComplete"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
				}
			}
		}
		if (!(entity instanceof class_1309 _livEnt ? _livEnt.method_6039() : false) && class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle minecraft:block blackstone ~ ~2 ~ .5 .5 .5 2 100 normal");
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14742, class_3419.field_15248, 1, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14742, class_3419.field_15248, 1, (float) 0.5, false);
				}
			}
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(class_1294.field_5909, 100, 1));
			if (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.ULTIMATE_POWER) : false) {
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(GildedDoomModMobEffects.DEATHS_MARK, 100, 0));
			}
		}
		if (!((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7909() == GildedDoomModItems.BRUTAL_TOME) && class_3532.method_15395(class_5819.method_43047(), 1, 20) == 1) {
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle minecraft:block gilded_blackstone ~ ~2 ~ .5 .5 .5 2 100 normal");
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14742, class_3419.field_15248, 1, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14742, class_3419.field_15248, 1, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14833, class_3419.field_15248, 1, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14833, class_3419.field_15248, 1, (float) 0.5, false);
				}
			}
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_STASIS, 40, 0));
		}
		HammerEnchantsProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("sourceentity", sourceentity).build());
	}
}
