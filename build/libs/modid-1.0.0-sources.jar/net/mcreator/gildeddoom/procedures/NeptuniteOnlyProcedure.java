package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_161;
import net.minecraft.class_1657;
import net.minecraft.class_167;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.Map;
import java.util.Iterator;

public class NeptuniteOnlyProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure NeptuniteOnly!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure NeptuniteOnly!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure NeptuniteOnly!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure NeptuniteOnly!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure NeptuniteOnly!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure NeptuniteOnly!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("purgatorytracker", entity) >= 2) {
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 100);
			if (entity.method_5715()) {
				{
					class_1297 _ent = entity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("warpx");
					if (_so == null)
						_so = _sc.method_1168("warpx", class_274.field_1468, class_2561.method_43470("warpx"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128((int) x);
				}
				{
					class_1297 _ent = entity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("warpy");
					if (_so == null)
						_so = _sc.method_1168("warpy", class_274.field_1468, class_2561.method_43470("warpy"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128((int) y);
				}
				{
					class_1297 _ent = entity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("warpz");
					if (_so == null)
						_so = _sc.method_1168("warpz", class_274.field_1468, class_2561.method_43470("warpz"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128((int) z);
				}
				if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
					_player.method_7353(class_2561.method_43470("Purgatory Return Location Set"), true);
				if (world instanceof class_3218 _level)
					_level.method_14199(class_2398.field_11214, x, y, z, 15, 2, 3, 2, 0);
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14891, class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_14891, class_3419.field_15254, 1, 1, false);
					}
				}
			} else {
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14669, class_3419.field_15254, 1, (float) 1.25);
					} else {
						_level.method_8486(x, y, z, class_3417.field_14669, class_3419.field_15254, 1, (float) 1.25, false);
					}
				}
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_STASIS, 80, 0));
				new Object() {
					private int ticks = 0;

					public void startDelay(class_1936 world) {
						ServerTickEvents.END_SERVER_TICK.register((server) -> {
							this.ticks++;
							if (this.ticks == 80) {
								if (world instanceof class_1937 _level) {
									if (!_level.method_8608()) {
										_level.method_8396(null, new class_2338(x, y, z), class_3417.field_22451, class_3419.field_15254, 1, 2);
									} else {
										_level.method_8486(x, y, z, class_3417.field_22451, class_3419.field_15254, 1, 2, false);
									}
								}
								if (world instanceof class_1937 _level) {
									if (!_level.method_8608()) {
										_level.method_8396(null, new class_2338(x, y, z), class_3417.field_23790, class_3419.field_15254, 1, 2);
									} else {
										_level.method_8486(x, y, z, class_3417.field_23790, class_3419.field_15254, 1, 2, false);
									}
								}
								if (world instanceof class_1937 _level) {
									if (!_level.method_8608()) {
										_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14879, class_3419.field_15254, 1, 1);
									} else {
										_level.method_8486(x, y, z, class_3417.field_14879, class_3419.field_15254, 1, 1, false);
									}
								}
								if (world instanceof class_3218 _level)
									_level.method_14199(class_2398.field_11214, x, y, z, 15, 2, 3, 2, 0);
								if ((entity.field_6002.method_27983()) == (class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension")))) {
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("purgatory");
										if (_so == null)
											_so = _sc.method_1168("purgatory", class_274.field_1468, class_2561.method_43470("purgatory"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(2);
									}
									{
										class_1297 _ent = entity;
										if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
											_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(),
													_ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4, _ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent),
													("/execute in minecraft:overworld run tp @s " + (new Object() {
														public int getScore(String score, class_1297 _ent) {
															class_269 _sc = _ent.method_37908().method_8428();
															class_266 _so = _sc.method_1170(score);
															if (_so != null)
																return _sc.method_1180(_ent.method_5820(), _so).method_1126();
															return 0;
														}
													}.getScore("warpx", entity)) + " " + (new Object() {
														public int getScore(String score, class_1297 _ent) {
															class_269 _sc = _ent.method_37908().method_8428();
															class_266 _so = _sc.method_1170(score);
															if (_so != null)
																return _sc.method_1180(_ent.method_5820(), _so).method_1126();
															return 0;
														}
													}.getScore("warpy", entity)) + " " + (new Object() {
														public int getScore(String score, class_1297 _ent) {
															class_269 _sc = _ent.method_37908().method_8428();
															class_266 _so = _sc.method_1170(score);
															if (_so != null)
																return _sc.method_1180(_ent.method_5820(), _so).method_1126();
															return 0;
														}
													}.getScore("warpz", entity))));
										}
									}
									{
										class_1297 _ent = entity;
										if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
											_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(),
													_ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4, _ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent),
													("/execute in minecraft:overworld run spawnpoint @s " + (new Object() {
														public int getScore(String score, class_1297 _ent) {
															class_269 _sc = _ent.method_37908().method_8428();
															class_266 _so = _sc.method_1170(score);
															if (_so != null)
																return _sc.method_1180(_ent.method_5820(), _so).method_1126();
															return 0;
														}
													}.getScore("warpx", entity)) + " " + (new Object() {
														public int getScore(String score, class_1297 _ent) {
															class_269 _sc = _ent.method_37908().method_8428();
															class_266 _so = _sc.method_1170(score);
															if (_so != null)
																return _sc.method_1180(_ent.method_5820(), _so).method_1126();
															return 0;
														}
													}.getScore("warpy", entity)) + " " + (new Object() {
														public int getScore(String score, class_1297 _ent) {
															class_269 _sc = _ent.method_37908().method_8428();
															class_266 _so = _sc.method_1170(score);
															if (_so != null)
																return _sc.method_1180(_ent.method_5820(), _so).method_1126();
															return 0;
														}
													}.getScore("warpz", entity))));
										}
									}
									if (entity instanceof class_3222 _player) {
										class_161 _adv = _player.field_13995.method_3851().method_12896(new class_2960("gilded_doom:freeatlast"));
										class_167 _ap = _player.method_14236().method_12882(_adv);
										if (!_ap.method_740()) {
											Iterator _iterator = _ap.method_731().iterator();
											while (_iterator.hasNext())
												_player.method_14236().method_12878(_adv, (String) _iterator.next());
										}
									}
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("DuckSouls");
										if (_so == null)
											_so = _sc.method_1168("DuckSouls", class_274.field_1468, class_2561.method_43470("DuckSouls"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
									}
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("WitherSouls");
										if (_so == null)
											_so = _sc.method_1168("WitherSouls", class_274.field_1468, class_2561.method_43470("WitherSouls"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
									}
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("PiglinBruteSouls");
										if (_so == null)
											_so = _sc.method_1168("PiglinBruteSouls", class_274.field_1468, class_2561.method_43470("PiglinBruteSouls"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
									}
								} else {
									{
										class_1297 _ent = entity;
										class_269 _sc = _ent.method_37908().method_8428();
										class_266 _so = _sc.method_1170("purgatory");
										if (_so == null)
											_so = _sc.method_1168("purgatory", class_274.field_1468, class_2561.method_43470("purgatory"), class_274.class_275.field_1472);
										_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
									}
									PurgatoryAmalgamRightclickedProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
								}
								return;
							}
						});
					}
				}.startDelay(world);
			}
		} else {
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 20);
			if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
				_entity.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_STASIS, 60, 0));
			new Object() {
				private int ticks = 0;

				public void startDelay(class_1936 world) {
					ServerTickEvents.END_SERVER_TICK.register((server) -> {
						this.ticks++;
						if (this.ticks == 60) {
							{
								class_1297 _ent = entity;
								if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
									_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
											_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "/execute in minecraft:overworld run spawnpoint @s ~ ~ ~");
								}
							}
							if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
								_player.method_7353(class_2561.method_43470("Respawn Set (In Overworld)"), false);
							return;
						}
					});
				}
			}.startDelay(world);
		}
	}
}
