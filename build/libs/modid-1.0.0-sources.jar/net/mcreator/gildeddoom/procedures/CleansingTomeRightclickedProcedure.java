package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class CleansingTomeRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure CleansingTomeRightclicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure CleansingTomeRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure CleansingTomeRightclicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure CleansingTomeRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure CleansingTomeRightclicked!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure CleansingTomeRightclicked!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.PENDING_DEATH) : false) {
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("pendingdeath");
				if (_so == null)
					_so = _sc.method_1168("pendingdeath", class_274.field_1468, class_2561.method_43470("pendingdeath"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(5);
			}
			if (entity instanceof class_1309 _entity)
				_entity.method_6016(GildedDoomModMobEffects.PENDING_DEATH);
			if (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("deathcurse", entity) == 3) {
				if (world instanceof class_3218 _level)
					_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
							("tempban " + entity.method_5820() + " 7d Evasion Penalty"));
			} else if (new Object() {
				public int getScore(String score, class_1297 _ent) {
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170(score);
					if (_so != null)
						return _sc.method_1180(_ent.method_5820(), _so).method_1126();
					return 0;
				}
			}.getScore("deathcurse", entity) > 0) {
				{
					class_1297 _ent = entity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("deathcurse");
					if (_so == null)
						_so = _sc.method_1168("deathcurse", class_274.field_1468, class_2561.method_43470("deathcurse"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128((int) (new Object() {
						public int getScore(String score, class_1297 _ent) {
							class_269 _sc = _ent.method_37908().method_8428();
							class_266 _so = _sc.method_1170(score);
							if (_so != null)
								return _sc.method_1180(_ent.method_5820(), _so).method_1126();
							return 0;
						}
					}.getScore("deathcurse", entity) + 1));
				}
			} else {
				{
					class_1297 _ent = entity;
					class_269 _sc = _ent.method_37908().method_8428();
					class_266 _so = _sc.method_1170("deathcurse");
					if (_so == null)
						_so = _sc.method_1168("deathcurse", class_274.field_1468, class_2561.method_43470("deathcurse"), class_274.class_275.field_1472);
					_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14905, class_3419.field_15254, 1, 1);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14905, class_3419.field_15254, 1, 1, false);
				}
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15136, class_3419.field_15254, 1, 1);
				} else {
					_level.method_8486(x, y, z, class_3417.field_15136, class_3419.field_15254, 1, 1, false);
				}
			}
			(itemstack).method_7934(1);
		}
	}
}
