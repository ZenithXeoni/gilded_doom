package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2183;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;
import java.util.ArrayList;

public class TrackingTomeRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure TrackingTomeRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure TrackingTomeRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure TrackingTomeRightclicked!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure TrackingTomeRightclicked!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == GildedDoomModItems.TRACKING_TOME
				|| (entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.ULTIMATE_POWER) : false) || (entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.GILDED_EMPOWERMENT) : false)
				|| (entity instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.GILDED_IMMUNITY) : false)) {
			for (class_1297 entityiterator : new ArrayList<>(world.method_18456())) {
				if (!((entityiterator instanceof class_1309 _livEnt ? _livEnt.method_6059(class_1294.field_5910) : false) || (entityiterator instanceof class_1309 _livEnt ? _livEnt.method_6059(class_1294.field_5905) : false)
						|| (entityiterator instanceof class_1309 _livEnt ? _livEnt.method_6059(GildedDoomModMobEffects.GILDED_IMMUNITY) : false)
						|| (entityiterator instanceof class_1309 _livEnt ? _livEnt.method_6059(class_1294.field_5907) : false))
						&& (entityiterator.method_5476().getString()).equals((entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7948().method_10558("PlayerSoul"))) {
					entity.method_5702(class_2183.class_2184.field_9851, new class_243((entityiterator.method_23317()), y, (entityiterator.method_23321())));
					if (entityiterator instanceof class_1657 _player && !_player.field_6002.method_8608())
						_player.method_7353(class_2561.method_43470("You are being tracked."), true);
					if (entity instanceof class_1657 _player)
						_player.method_7357().method_7906(itemstack.method_7909(), 3000);
					if (entityiterator instanceof class_1309 _entity && !_entity.field_6002.method_8608())
						_entity.method_6092(new class_1293(class_1294.field_5912, 300, 1));
				}
			}
		}
	}
}
