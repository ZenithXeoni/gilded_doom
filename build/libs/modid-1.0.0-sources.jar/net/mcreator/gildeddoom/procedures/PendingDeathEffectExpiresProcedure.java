package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.Map;

public class PendingDeathEffectExpiresProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure PendingDeathEffectExpires!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure PendingDeathEffectExpires!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure PendingDeathEffectExpires!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure PendingDeathEffectExpires!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure PendingDeathEffectExpires!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 2) {
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("pendingdeath");
				if (_so == null)
					_so = _sc.method_1168("pendingdeath", class_274.field_1468, class_2561.method_43470("pendingdeath"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("Soulbanned");
				if (_so == null)
					_so = _sc.method_1168("Soulbanned", class_274.field_1468, class_2561.method_43470("Soulbanned"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(1);
			}
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:block.respawn_anchor.ambient master @a ~ ~ ~ 1 0.5");
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:block.respawn_anchor.deplete master @a ~ ~ ~ 1 0.5");
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 0.73");
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5");
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_1937 _level && !_level.method_8608())
				_level.method_8437(null, x, y, z, 10, class_1927.class_4179.field_18687);
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						("ban " + entity.method_5476().getString() + " Your time is over, rest well..."));
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"tellraw @a {\"text\":\"No mortal shall escape the Gilded Embrace of Doom.\",\"bold\":true,\"italic\":true,\"color\":\"yellow\"}");
		}
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 1) {
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("pendingdeath");
				if (_so == null)
					_so = _sc.method_1168("pendingdeath", class_274.field_1468, class_2561.method_43470("pendingdeath"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14792, class_3419.field_15248, 25, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14792, class_3419.field_15248, 25, (float) 0.5, false);
				}
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
			if (world instanceof class_1937 _level && !_level.method_8608())
				_level.method_8437(null, x, y, z, 3, class_1927.class_4179.field_18687);
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s pickyourpoison:vulnerability");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s pickyourpoison:numbness");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s pickyourpoison:batrachotoxin");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s minecraft:wither");
				}
			}
			{
				class_1297 _ent = entity;
				if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
					_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
							_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "kill @s");
				}
			}
			new Object() {
				private int ticks = 0;

				public void startDelay(class_1936 world) {
					ServerTickEvents.END_SERVER_TICK.register((server) -> {
						this.ticks++;
						if (this.ticks == 100) {
							{
								class_1297 _ent = entity;
								if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
									_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
											_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s pickyourpoison:vulnerability");
								}
							}
							{
								class_1297 _ent = entity;
								if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
									_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
											_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s pickyourpoison:numbness");
								}
							}
							{
								class_1297 _ent = entity;
								if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
									_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
											_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s pickyourpoison:batrachotoxin");
								}
							}
							{
								class_1297 _ent = entity;
								if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
									_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
											_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "effect clear @s minecraft:wither");
								}
							}
							{
								class_1297 _ent = entity;
								if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
									_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
											_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "kill @s");
								}
							}
							return;
						}
					});
				}
			}.startDelay(world);
			if (world instanceof class_3218 _level)
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"tellraw @a {\"text\":\"No mortal shall escape the Gilded Embrace of Doom.\",\"italic\":true,\"color\":\"yellow\"}");
		}
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 5) {
			{
				class_1297 _ent = entity;
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170("pendingdeath");
				if (_so == null)
					_so = _sc.method_1168("pendingdeath", class_274.field_1468, class_2561.method_43470("pendingdeath"), class_274.class_275.field_1472);
				_sc.method_1180(_ent.method_5820(), _so).method_1128(0);
			}
		} else if (!(new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 1 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 2 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 3 && new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("pendingdeath", entity) == 4)) {
			if (world instanceof class_1937 _level) {
				if (!_level.method_8608()) {
					_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14792, class_3419.field_15248, 1, (float) 0.5);
				} else {
					_level.method_8486(x, y, z, class_3417.field_14792, class_3419.field_15248, 1, (float) 0.5, false);
				}
			}
			if (world instanceof class_1937 _level && !_level.method_8608())
				_level.method_8437(null, x, y, z, 2, class_1927.class_4179.field_18685);
			if (world instanceof class_3218 _level) {
				class_1538 entityToSpawn = class_1299.field_6112.method_5883(_level);
				entityToSpawn.method_29495(class_243.method_24955(new class_2338(x, y, z)));
				entityToSpawn.method_29498(true);
				_level.method_8649(entityToSpawn);
			}
		}
	}
}
