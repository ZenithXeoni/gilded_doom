package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.mcreator.gildeddoom.GildedDoomMod;

import java.util.Map;

public class ImmunityTomeRightclickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure ImmunityTomeRightclicked!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency itemstack for procedure ImmunityTomeRightclicked!");
			return;
		}
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1799 itemstack = (class_1799) dependencies.get("itemstack");
		if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
			_entity.method_6092(new class_1293(GildedDoomModMobEffects.GILDED_IMMUNITY, 600, 0));
		if (entity instanceof class_1657 _player)
			_player.method_7357().method_7906(itemstack.method_7909(), 3600);
	}
}
