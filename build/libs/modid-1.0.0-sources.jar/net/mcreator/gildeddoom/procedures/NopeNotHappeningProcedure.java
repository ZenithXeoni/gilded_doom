package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.GildedDoomMod;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import java.util.Map;
import java.util.HashMap;

public class NopeNotHappeningProcedure {
	public NopeNotHappeningProcedure() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("entity", handler.method_32311());
			dependencies.put("x", handler.method_32311().method_23317());
			dependencies.put("y", handler.method_32311().method_23318());
			dependencies.put("z", handler.method_32311().method_23321());
			dependencies.put("world", handler.method_32311().method_14220());
			execute(dependencies);
		});
	}

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure NopeNotHappening!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure NopeNotHappening!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		class_1297 entity = (class_1297) dependencies.get("entity");
		if (new Object() {
			public int getScore(String score, class_1297 _ent) {
				class_269 _sc = _ent.method_37908().method_8428();
				class_266 _so = _sc.method_1170(score);
				if (_so != null)
					return _sc.method_1180(_ent.method_5820(), _so).method_1126();
				return 0;
			}
		}.getScore("purgatory", entity) == 1 && !((class_5321.method_29179(class_2378.field_25298, new class_2960("gilded_doom:purgatory_dimension"))) == (world instanceof class_1937 _lvl ? _lvl.method_27983() : class_1937.field_25179))) {
			if (entity instanceof class_1657 _player && !_player.field_6002.method_8608())
				_player.method_7353(class_2561.method_43470("Oh no you dont."), false);
			PurgatoryAmalgamRightclickedProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
		}
	}
}
