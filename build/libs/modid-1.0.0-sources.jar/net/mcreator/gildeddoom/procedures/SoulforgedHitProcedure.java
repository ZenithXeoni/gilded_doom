package net.mcreator.gildeddoom.procedures;

import net.mcreator.gildeddoom.init.GildedDoomModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.mcreator.gildeddoom.init.GildedDoomModItems;
import net.mcreator.gildeddoom.init.GildedDoomModEnchantments;
import net.mcreator.gildeddoom.GildedDoomMod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.Map;

public class SoulforgedHitProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency world for procedure SoulforgedHit!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency x for procedure SoulforgedHit!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency y for procedure SoulforgedHit!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency z for procedure SoulforgedHit!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency entity for procedure SoulforgedHit!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				GildedDoomMod.LOGGER.warn("Failed to load dependency sourceentity for procedure SoulforgedHit!");
			return;
		}
		class_1936 world = (class_1936) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		class_1297 entity = (class_1297) dependencies.get("entity");
		class_1297 sourceentity = (class_1297) dependencies.get("sourceentity");
		if (!(entity instanceof class_1309 _livEnt ? _livEnt.method_6039() : false)) {
			entity.method_5639(8);
			if ((class_1890.method_8225(GildedDoomModEnchantments.KNOCKOUT, (sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037)) != 0
					? !(class_3532.method_15395(class_5819.method_43047(), 1, 2) == 1)
					: class_3532.method_15395(class_5819.method_43047(), 1, 4) == 1) || (entity.field_6002.method_27983()) == class_1937.field_25180) {
				{
					class_1297 _ent = entity;
					if (!_ent.field_6002.method_8608() && _ent.method_5682() != null) {
						_ent.method_5682().method_3734().method_44252(new class_2168(class_2165.field_17395, _ent.method_19538(), _ent.method_5802(), _ent.field_6002 instanceof class_3218 ? (class_3218) _ent.field_6002 : null, 4,
								_ent.method_5477().getString(), _ent.method_5476(), _ent.field_6002.method_8503(), _ent), "particle minecraft:soul_fire_flame ~ ~2 ~ .5 .5 .5 1 25 normal");
					}
				}
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14588, class_3419.field_15248, 1, (float) 0.8);
					} else {
						_level.method_8486(x, y, z, class_3417.field_14588, class_3419.field_15248, 1, (float) 0.8, false);
					}
				}
				new Object() {
					private int ticks = 0;

					public void startDelay(class_1936 world) {
						ServerTickEvents.END_SERVER_TICK.register((server) -> {
							this.ticks++;
							if (this.ticks == 1) {
								if (world instanceof class_1937 _level) {
									if (!_level.method_8608()) {
										_level.method_8396(null, new class_2338(x, y, z), class_3417.field_14917, class_3419.field_15248, 1, 1);
									} else {
										_level.method_8486(x, y, z, class_3417.field_14917, class_3419.field_15248, 1, 1, false);
									}
								}
								if (world instanceof class_1937 _level) {
									if (!_level.method_8608()) {
										_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15188, class_3419.field_15248, 1, 1);
									} else {
										_level.method_8486(x, y, z, class_3417.field_15188, class_3419.field_15248, 1, 1, false);
									}
								}
								return;
							}
						});
					}
				}.startDelay(world);
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(class_1294.field_5911, 100, 0));
			}
			if (class_3532.method_15395(class_5819.method_43047(), 1, 16) == 1 && !((sourceentity instanceof class_1309 _livEnt ? _livEnt.method_6079() : class_1799.field_8037).method_7909() == GildedDoomModItems.WITHERING_TOME)) {
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, new class_2338(x, y, z), class_3417.field_15027, class_3419.field_15248, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_3417.field_15027, class_3419.field_15248, 1, 1, false);
					}
				}
				if (entity instanceof class_1309 _entity && !_entity.field_6002.method_8608())
					_entity.method_6092(new class_1293(GildedDoomModMobEffects.THE_ECHO_FALL_EXPERIENCE, 200, 0));
			}
		}
		HammerEnchantsProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).put("entity", entity).put("sourceentity", sourceentity).build());
	}
}
