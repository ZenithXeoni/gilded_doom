package net.mcreator.gildeddoom.client.renderer;

import net.mcreator.gildeddoom.entity.DuckEntity;
import net.minecraft.class_2960;
import net.minecraft.class_558;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class DuckRenderer extends class_927<DuckEntity, class_558<DuckEntity>> {
	public DuckRenderer(class_5617.class_5618 context) {
		super(context, new class_558(context.method_32167(class_5602.field_27691)), 0.5f);
	}

	@Override
	public class_2960 getTextureLocation(DuckEntity entity) {
		return new class_2960("gilded_doom:textures/entities/duck.png");
	}
}
