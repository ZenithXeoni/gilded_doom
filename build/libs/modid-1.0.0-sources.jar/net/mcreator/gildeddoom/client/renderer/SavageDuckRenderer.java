package net.mcreator.gildeddoom.client.renderer;

import net.mcreator.gildeddoom.entity.SavageDuckEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4606;
import net.minecraft.class_558;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class SavageDuckRenderer extends class_927<SavageDuckEntity, class_558<SavageDuckEntity>> {
	public SavageDuckRenderer(class_5617.class_5618 context) {
		super(context, new class_558(context.method_32167(class_5602.field_27691)), 0.5f);
		this.method_4046(new class_4606<SavageDuckEntity, class_558<SavageDuckEntity>>(this) {
			@Override
			public class_1921 method_23193() {
				return class_1921.method_23026(new class_2960("gilded_doom:textures/entities/savage_duck.png"));
			}
		});
	}

	@Override
	public class_2960 getTextureLocation(SavageDuckEntity entity) {
		return new class_2960("gilded_doom:textures/entities/savage_duck.png");
	}
}
