package net.mcreator.gildeddoom.entity;

import net.mcreator.gildeddoom.procedures.DuckRightClickedOnEntityProcedure;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1295;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1310;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1379;
import net.minecraft.class_1399;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1686;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.mcreator.gildeddoom.procedures.DuckEntityDiesProcedure;
import net.mcreator.gildeddoom.init.GildedDoomModSounds;
import net.mcreator.gildeddoom.init.GildedDoomModItems;

public class DuckEntity extends class_1314 {
	public DuckEntity(class_1299<DuckEntity> type, class_1937 world) {
		super(type, world);
		field_6013 = 0.6f;
		field_6194 = 3;
		method_5977(false);
	}

	@Override
	protected void method_5959() {
		super.method_5959();
		this.field_6201.method_6277(1, new class_1366(this, 1.2, false) {
			@Override
			protected double method_6289(class_1309 entity) {
				return this.field_6503.method_17681() * this.field_6503.method_17681() + entity.method_17681();
			}
		});
		this.field_6201.method_6277(2, new class_1379(this, 1));
		this.field_6185.method_6277(3, new class_1399(this));
		this.field_6201.method_6277(4, new class_1376(this));
		this.field_6201.method_6277(5, new class_1347(this));
	}

	@Override
	public class_1310 method_6046() {
		return class_1310.field_6290;
	}

	protected void method_6099(class_1282 source, int looting, boolean recentlyHitIn) {
		super.method_6099(source, looting, recentlyHitIn);
		this.method_5775(new class_1799(GildedDoomModItems.DEMONIC_DUST));
	}

	@Override
	public class_3414 method_5994() {
		return GildedDoomModSounds.GOT_ANY_GRAPES;
	}

	@Override
	public void method_5712(class_2338 pos, class_2680 blockIn) {
		this.method_5783(class_3417.field_14685, 0.15f, 1);
	}

	@Override
	public class_3414 method_6011(class_1282 ds) {
		return class_3417.field_14601;
	}

	@Override
	public class_3414 method_6002() {
		return class_3417.field_15140;
	}

	@Override
	public boolean method_5643(class_1282 source, float amount) {
		if (source.method_5526() instanceof class_1665)
			return false;
		if (source.method_5526() instanceof class_1686 || source.method_5526() instanceof class_1295)
			return false;
		if (source == class_1282.field_5868)
			return false;
		if (source == class_1282.field_5848)
			return false;
		if (source == class_1282.field_5859)
			return false;
		if (source == class_1282.field_5861)
			return false;
		if (source.method_5535())
			return false;
		if (source.method_5525().equals("trident"))
			return false;
		if (source == class_1282.field_5865)
			return false;
		if (source == class_1282.field_5856)
			return false;
		if (source == class_1282.field_5850)
			return false;
		if (source.method_5525().equals("witherSkull"))
			return false;
		return super.method_5643(source, amount);
	}

	@Override
	public void method_6078(class_1282 source) {
		super.method_6078(source);
		double x = this.method_23317();
		double y = this.method_23318();
		double z = this.method_23321();
		class_1297 sourceentity = source.method_5529();
		class_1297 entity = this;
		class_1937 world = this.field_6002;
		DuckEntityDiesProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("world", world).put("x", x).put("y", y).put("z", z).build());
	}

	@Override
	public class_1269 method_5992(class_1657 sourceentity, class_1268 hand) {
		class_1799 itemstack = sourceentity.method_5998(hand);
		class_1269 retval = class_1269.method_29236(this.field_6002.method_8608());
		super.method_5992(sourceentity, hand);
		double x = this.method_23317();
		double y = this.method_23318();
		double z = this.method_23321();
		class_1297 entity = this;
		class_1937 world = this.field_6002;
		DuckRightClickedOnEntityProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).put("itemstack", itemstack).build());
		return retval;
	}

	public static void init() {
	}

	public static class_5132.class_5133 createAttributes() {
		class_5132.class_5133 builder = class_1308.method_26828();
		builder = builder.method_26868(class_5134.field_23719, 0.3);
		builder = builder.method_26868(class_5134.field_23716, 10);
		builder = builder.method_26868(class_5134.field_23724, 0);
		builder = builder.method_26868(class_5134.field_23721, 3);
		builder = builder.method_26868(class_5134.field_23717, 16);
		return builder;
	}
}
