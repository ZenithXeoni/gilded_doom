package net.mcreator.gildeddoom.network;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1657;
import net.minecraft.class_18;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_3218;
import net.minecraft.class_5425;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;

public class GildedDoomModVariables {
	public static void SyncJoin() {
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (entity instanceof class_1657) {
				if (!world.method_8608()) {
					class_18 mapdata = MapVariables.get(world);
					class_18 worlddata = WorldVariables.get(world);
				}
			}
		});
	}

	public static void SyncChangeWorld() {
		ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
			if (!destination.method_8608()) {
				class_18 worlddata = WorldVariables.get(destination);
			}
		});
	}

	public static class WorldVariables extends class_18 {
		public static final String DATA_NAME = "gilded_doom_worldvars";

		public static WorldVariables load(class_2487 tag) {
			WorldVariables data = new WorldVariables();
			data.read(tag);
			return data;
		}

		public void read(class_2487 nbt) {
		}

		@Override
		public class_2487 method_75(class_2487 nbt) {
			return nbt;
		}

		public void syncData(class_1936 world) {
			this.method_80();
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(class_1936 world) {
			if (world instanceof class_3218 level) {
				return level.method_17983().method_17924(e -> WorldVariables.load(e), WorldVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends class_18 {
		public static final String DATA_NAME = "gilded_doom_mapvars";
		public double obx = 0;
		public double obz = 0;
		public double oby = 0;
		public boolean bookfound = false;

		public static MapVariables load(class_2487 tag) {
			MapVariables data = new MapVariables();
			data.read(tag);
			return data;
		}

		public void read(class_2487 nbt) {
			obx = nbt.method_10574("obx");
			obz = nbt.method_10574("obz");
			oby = nbt.method_10574("oby");
			bookfound = nbt.method_10577("bookfound");
		}

		@Override
		public class_2487 method_75(class_2487 nbt) {
			nbt.method_10549("obx", obx);
			nbt.method_10549("obz", obz);
			nbt.method_10549("oby", oby);
			nbt.method_10556("bookfound", bookfound);
			return nbt;
		}

		public void syncData(class_1936 world) {
			this.method_80();
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(class_1936 world) {
			if (world instanceof class_5425 serverLevelAcc) {
				return serverLevelAcc.method_8410().method_8503().method_3847(class_1937.field_25179).method_17983().method_17924(e -> MapVariables.load(e), MapVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class SavedDataSyncMessage {
		public int type;
		public class_18 data;

		public SavedDataSyncMessage(class_2540 buffer) {
			this.type = buffer.readInt();
			this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
			if (this.data instanceof MapVariables _mapvars)
				_mapvars.read(buffer.method_10798());
			else if (this.data instanceof WorldVariables _worldvars)
				_worldvars.read(buffer.method_10798());
		}

		public SavedDataSyncMessage(int type, class_18 data) {
			this.type = type;
			this.data = data;
		}

		public static void buffer(SavedDataSyncMessage message, class_2540 buffer) {
			buffer.writeInt(message.type);
			buffer.method_10794(message.data.method_75(new class_2487()));
		}
	}
}
